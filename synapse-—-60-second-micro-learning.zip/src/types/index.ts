export type Discipline = 
  | 'All'
  | 'Neuroscience'
  | 'Physics & Quantum'
  | 'Behavioral Economics'
  | 'Architectural History'
  | 'Algorithms & Systems'
  | 'Philosophy & Logic';

export interface SlideBeat {
  id: string;
  startSec: number;
  endSec: number;
  title: string;
  subtitle: string;
  script: string;
  bulletPoints?: string[];
  keyFormulaOrConcept?: string;
  diagramType?: 'synapse' | 'quantum' | 'decoy_pricing' | 'pantheon' | 'bloom_filter' | 'theseus' | 'custom';
}

export interface QuizQuestion {
  question: string;
  options: string[];
  correctIndex: number;
  explanation: string;
}

export interface Author {
  id: string;
  name: string;
  handle: string;
  role: string;
  institution: string;
  avatarUrl?: string;
  followersCount: number;
  lessonsCount: number;
  verified: boolean;
}

export interface Citation {
  title: string;
  source: string;
  year: number;
  doiOrUrl?: string;
}

export interface TeachBackComment {
  id: string;
  authorName: string;
  authorHandle: string;
  timestamp: string;
  content: string;
  likes: number;
  isFeynmanSummary?: boolean;
}

export interface Lesson {
  id: string;
  title: string;
  tagline: string;
  discipline: Discipline;
  durationSec: number; // Always 60
  author: Author;
  coverImage?: string;
  publishedAt: string;
  mindSparks: number; // thoughtful reactions
  savesCount: number;
  beats: SlideBeat[];
  quiz: QuizQuestion;
  keyTakeaway: string;
  citation: Citation;
  difficulty: 'Beginner' | 'Intermediate' | 'Advanced';
  comments: TeachBackComment[];
}

export interface UserProgress {
  cqPoints: number; // Curiosity Quotient
  dailyLearningMinutes: number;
  streakDays: number;
  completedLessonIds: string[];
  savedLessonIds: string[];
  followingAuthorIds: string[];
  likedLessonIds: string[];
  passedQuizLessonIds: string[];
}
