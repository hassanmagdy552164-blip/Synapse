import React, { useState, useEffect } from 'react';
import { Lesson, UserProgress } from './types';
import {
  getStoredLessons,
  saveNewLesson,
  updateStoredLesson,
  getStoredUserProgress,
  saveUserProgress,
} from './services/storage';
import { Header } from './components/Header';
import { StreamPlayer } from './components/StreamPlayer';
import { CatalogGrid } from './components/CatalogGrid';
import { VaultDrawer } from './components/VaultDrawer';
import { CreatorStudioModal } from './components/CreatorStudioModal';
import { DiscussionModal } from './components/DiscussionModal';
import { AuthorProfileModal } from './components/AuthorProfileModal';

export default function App() {
  const [lessons, setLessons] = useState<Lesson[]>(getStoredLessons);
  const [userProgress, setUserProgress] = useState<UserProgress>(getStoredUserProgress);
  const [currentView, setCurrentView] = useState<'stream' | 'catalog'>('stream');
  const [currentLessonIndex, setCurrentLessonIndex] = useState(0);

  // Modals & Drawers
  const [isVaultOpen, setIsVaultOpen] = useState(false);
  const [isStudioOpen, setIsStudioOpen] = useState(false);
  const [discussionLesson, setDiscussionLesson] = useState<Lesson | null>(null);
  const [selectedAuthorId, setSelectedAuthorId] = useState<string | null>(null);

  // Sync user progress whenever it updates
  useEffect(() => {
    saveUserProgress(userProgress);
  }, [userProgress]);

  // Social action handlers
  const handleToggleLike = (lessonId: string) => {
    setUserProgress((prev) => {
      const isLiked = prev.likedLessonIds.includes(lessonId);
      const updatedLiked = isLiked
        ? prev.likedLessonIds.filter((id) => id !== lessonId)
        : [...prev.likedLessonIds, lessonId];

      const newCq = isLiked ? Math.max(0, prev.cqPoints - 5) : prev.cqPoints + 5;

      return {
        ...prev,
        likedLessonIds: updatedLiked,
        cqPoints: newCq,
      };
    });
  };

  const handleToggleSave = (lessonId: string) => {
    setUserProgress((prev) => {
      const isSaved = prev.savedLessonIds.includes(lessonId);
      const updatedSaved = isSaved
        ? prev.savedLessonIds.filter((id) => id !== lessonId)
        : [...prev.savedLessonIds, lessonId];

      return {
        ...prev,
        savedLessonIds: updatedSaved,
      };
    });
  };

  const handleToggleFollow = (authorId: string) => {
    setUserProgress((prev) => {
      const isFollowing = prev.followingAuthorIds.includes(authorId);
      const updatedFollowing = isFollowing
        ? prev.followingAuthorIds.filter((id) => id !== authorId)
        : [...prev.followingAuthorIds, authorId];

      return {
        ...prev,
        followingAuthorIds: updatedFollowing,
      };
    });
  };

  const handlePassQuiz = (lessonId: string) => {
    setUserProgress((prev) => {
      if (prev.passedQuizLessonIds.includes(lessonId)) return prev;
      return {
        ...prev,
        passedQuizLessonIds: [...prev.passedQuizLessonIds, lessonId],
        cqPoints: prev.cqPoints + 20,
        dailyLearningMinutes: prev.dailyLearningMinutes + 1,
      };
    });
  };

  const handleAddComment = (comment: any) => {
    if (!discussionLesson) return;
    const updatedLesson: Lesson = {
      ...discussionLesson,
      comments: [comment, ...discussionLesson.comments],
    };

    const nextLessons = updateStoredLesson(updatedLesson);
    setLessons(nextLessons);
    setDiscussionLesson(updatedLesson);

    // Reward for active Feynman contribution
    setUserProgress((prev) => ({
      ...prev,
      cqPoints: prev.cqPoints + 15,
    }));
  };

  const handlePublishLesson = (newLesson: Lesson) => {
    const updated = saveNewLesson(newLesson);
    setLessons(updated);
    setCurrentLessonIndex(0);
    setCurrentView('stream');

    setUserProgress((prev) => ({
      ...prev,
      cqPoints: prev.cqPoints + 50,
      dailyLearningMinutes: prev.dailyLearningMinutes + 1,
    }));
  };

  const handleSelectAuthor = (authorId: string) => {
    setSelectedAuthorId(authorId);
  };

  const currentAuthor = selectedAuthorId
    ? lessons.find((l) => l.author.id === selectedAuthorId)?.author || null
    : null;

  return (
    <div className="min-h-screen bg-slate-950 text-slate-100 flex flex-col font-sans pb-20 md:pb-8 selection:bg-cyan-500/20 selection:text-cyan-200">
      {/* Top Bar (Follows Section 2 Top Bar Contract) */}
      <Header
        currentView={currentView}
        onNavigate={(v) => setCurrentView(v)}
        onOpenVault={() => setIsVaultOpen(true)}
        onOpenStudio={() => setIsStudioOpen(true)}
        userProgress={userProgress}
      />

      {/* Main Content Area */}
      <main className="flex-1 w-full">
        {currentView === 'stream' ? (
          <StreamPlayer
            lessons={lessons}
            currentLessonIndex={currentLessonIndex}
            userProgress={userProgress}
            onLessonChange={(idx) => setCurrentLessonIndex(idx)}
            onToggleLike={handleToggleLike}
            onToggleSave={handleToggleSave}
            onToggleFollow={handleToggleFollow}
            onPassQuiz={handlePassQuiz}
            onOpenDiscussion={(l) => setDiscussionLesson(l)}
            onSelectAuthor={handleSelectAuthor}
            onSwitchToCatalog={() => setCurrentView('catalog')}
          />
        ) : (
          <CatalogGrid
            lessons={lessons}
            savedLessonIds={userProgress.savedLessonIds}
            likedLessonIds={userProgress.likedLessonIds}
            onPlayLesson={(l) => {
              const idx = lessons.findIndex((x) => x.id === l.id);
              if (idx !== -1) {
                setCurrentLessonIndex(idx);
                setCurrentView('stream');
              }
            }}
            onToggleSave={handleToggleSave}
            onToggleLike={handleToggleLike}
            onSelectAuthor={handleSelectAuthor}
            onOpenStudio={() => setIsStudioOpen(true)}
          />
        )}
      </main>

      {/* Mobile Fixed Bottom Navigation Bar (Section 3 of Mobile Reference) */}
      <nav className="md:hidden fixed bottom-0 left-0 right-0 z-40 bg-slate-950/95 backdrop-blur-md border-t border-slate-800 grid grid-cols-4 items-center h-16 px-2">
        <button
          type="button"
          onClick={() => setCurrentView('stream')}
          className={`flex flex-col items-center justify-center h-full min-h-[44px] transition-colors ${
            currentView === 'stream' ? 'text-cyan-400 font-semibold' : 'text-slate-400'
          }`}
        >
          <span className="text-base">▶</span>
          <span className="text-[10px] font-medium tracking-tight mt-0.5">Stream</span>
        </button>

        <button
          type="button"
          onClick={() => setCurrentView('catalog')}
          className={`flex flex-col items-center justify-center h-full min-h-[44px] transition-colors ${
            currentView === 'catalog' ? 'text-cyan-400 font-semibold' : 'text-slate-400'
          }`}
        >
          <span className="text-base">☷</span>
          <span className="text-[10px] font-medium tracking-tight mt-0.5">Discover</span>
        </button>

        <button
          type="button"
          onClick={() => setIsVaultOpen(true)}
          className="flex flex-col items-center justify-center h-full min-h-[44px] text-slate-400 hover:text-slate-200 transition-colors"
        >
          <span className="text-base">★</span>
          <span className="text-[10px] font-medium tracking-tight mt-0.5">My Vault</span>
        </button>

        <button
          type="button"
          onClick={() => setIsStudioOpen(true)}
          className="flex flex-col items-center justify-center h-full min-h-[44px] text-cyan-400 hover:text-cyan-300 transition-colors font-medium"
        >
          <span className="text-base">＋</span>
          <span className="text-[10px] tracking-tight mt-0.5 font-bold">Post 60s</span>
        </button>
      </nav>

      {/* Vault & Flashcard Spaced Repetition Drawer */}
      <VaultDrawer
        isOpen={isVaultOpen}
        onClose={() => setIsVaultOpen(false)}
        userProgress={userProgress}
        lessons={lessons}
        onSelectLesson={(l) => {
          const idx = lessons.findIndex((x) => x.id === l.id);
          if (idx !== -1) {
            setCurrentLessonIndex(idx);
            setCurrentView('stream');
          }
        }}
      />

      {/* 60s Lesson Creator Studio */}
      <CreatorStudioModal
        isOpen={isStudioOpen}
        onClose={() => setIsStudioOpen(false)}
        onPublish={handlePublishLesson}
      />

      {/* Feynman Teach-Back Discussion Forum Modal */}
      {discussionLesson && (
        <DiscussionModal
          lessonTitle={discussionLesson.title}
          comments={discussionLesson.comments}
          isOpen={Boolean(discussionLesson)}
          onClose={() => setDiscussionLesson(null)}
          onAddComment={handleAddComment}
        />
      )}

      {/* Scholar / Author Profile Modal */}
      {currentAuthor && (
        <AuthorProfileModal
          author={currentAuthor}
          lessons={lessons}
          isOpen={Boolean(selectedAuthorId)}
          isFollowing={userProgress.followingAuthorIds.includes(currentAuthor.id)}
          onToggleFollow={handleToggleFollow}
          onSelectLesson={(l) => {
            const idx = lessons.findIndex((x) => x.id === l.id);
            if (idx !== -1) {
              setCurrentLessonIndex(idx);
              setCurrentView('stream');
            }
          }}
          onClose={() => setSelectedAuthorId(null)}
        />
      )}
    </div>
  );
}
