import { Lesson, UserProgress } from '../types';
import { INITIAL_LESSONS } from '../data/initialLessons';

const LESSONS_KEY = 'synapse_lessons_v1';
const USER_PROGRESS_KEY = 'synapse_user_progress_v1';

export const getStoredLessons = (): Lesson[] => {
  if (typeof window === 'undefined') return INITIAL_LESSONS;
  try {
    const data = localStorage.getItem(LESSONS_KEY);
    if (!data) {
      localStorage.setItem(LESSONS_KEY, JSON.stringify(INITIAL_LESSONS));
      return INITIAL_LESSONS;
    }
    const parsed = JSON.parse(data);
    return Array.isArray(parsed) && parsed.length > 0 ? parsed : INITIAL_LESSONS;
  } catch (err) {
    console.error('Failed reading lessons from localStorage', err);
    return INITIAL_LESSONS;
  }
};

export const saveNewLesson = (lesson: Lesson): Lesson[] => {
  const current = getStoredLessons();
  const updated = [lesson, ...current];
  try {
    localStorage.setItem(LESSONS_KEY, JSON.stringify(updated));
  } catch (err) {
    console.error('Failed to save new lesson', err);
  }
  return updated;
};

export const updateStoredLesson = (updatedLesson: Lesson): Lesson[] => {
  const current = getStoredLessons();
  const index = current.findIndex(l => l.id === updatedLesson.id);
  if (index !== -1) {
    current[index] = updatedLesson;
    try {
      localStorage.setItem(LESSONS_KEY, JSON.stringify(current));
    } catch (e) {
      console.error(e);
    }
  }
  return [...current];
};

export const getStoredUserProgress = (): UserProgress => {
  const defaultProgress: UserProgress = {
    cqPoints: 340,
    dailyLearningMinutes: 6,
    streakDays: 4,
    completedLessonIds: ['lesson-glymphatic-system'],
    savedLessonIds: ['lesson-pantheon-concrete'],
    followingAuthorIds: ['author-elena'],
    likedLessonIds: ['lesson-glymphatic-system'],
    passedQuizLessonIds: ['lesson-glymphatic-system'],
  };

  if (typeof window === 'undefined') return defaultProgress;
  try {
    const raw = localStorage.getItem(USER_PROGRESS_KEY);
    if (!raw) {
      localStorage.setItem(USER_PROGRESS_KEY, JSON.stringify(defaultProgress));
      return defaultProgress;
    }
    return JSON.parse(raw);
  } catch {
    return defaultProgress;
  }
};

export const saveUserProgress = (progress: UserProgress) => {
  if (typeof window === 'undefined') return;
  try {
    localStorage.setItem(USER_PROGRESS_KEY, JSON.stringify(progress));
  } catch (e) {
    console.error('Failed saving user progress', e);
  }
};
