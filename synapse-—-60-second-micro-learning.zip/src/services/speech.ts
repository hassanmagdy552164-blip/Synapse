export class SpeechNarrator {
  private synth: SpeechSynthesis | null = null;
  private currentUtterance: SpeechSynthesisUtterance | null = null;
  private isSpeaking = false;
  private isPaused = false;
  private rate = 1.0;
  private pitch = 1.0;
  private onEndCallback: (() => void) | null = null;

  constructor() {
    if (typeof window !== 'undefined' && 'speechSynthesis' in window) {
      this.synth = window.speechSynthesis;
    }
  }

  public isAvailable(): boolean {
    return this.synth !== null;
  }

  public setRate(newRate: number) {
    this.rate = Math.max(0.75, Math.min(2.0, newRate));
    if (this.isSpeaking && !this.isPaused && this.currentUtterance) {
      // Re-trigger with new rate if currently speaking
      const text = this.currentUtterance.text;
      this.stop();
      this.speak(text, this.onEndCallback);
    }
  }

  public getRate(): number {
    return this.rate;
  }

  public speak(text: string, onEnd?: (() => void) | null) {
    if (!this.synth) return;

    this.stop();
    this.onEndCallback = onEnd || null;

    const utterance = new SpeechSynthesisUtterance(text);
    utterance.rate = this.rate;
    utterance.pitch = this.pitch;

    // Pick a natural, articulate voice if available
    const voices = this.synth.getVoices();
    const englishVoice = voices.find(
      (v) => (v.name.includes('Natural') || v.name.includes('Google') || v.name.includes('Samantha') || v.lang.startsWith('en')) && !v.name.includes('Zira')
    ) || voices.find((v) => v.lang.startsWith('en')) || voices[0];

    if (englishVoice) {
      utterance.voice = englishVoice;
    }

    utterance.onend = () => {
      this.isSpeaking = false;
      this.isPaused = false;
      if (this.onEndCallback) {
        this.onEndCallback();
      }
    };

    utterance.onerror = (e) => {
      console.warn('SpeechSynthesis error:', e);
      this.isSpeaking = false;
      this.isPaused = false;
      if (this.onEndCallback) {
        this.onEndCallback();
      }
    };

    this.currentUtterance = utterance;
    this.isSpeaking = true;
    this.isPaused = false;
    this.synth.speak(utterance);
  }

  public pause() {
    if (this.synth && this.isSpeaking && !this.isPaused) {
      this.synth.pause();
      this.isPaused = true;
    }
  }

  public resume() {
    if (this.synth && this.isPaused) {
      this.synth.resume();
      this.isPaused = false;
    }
  }

  public stop() {
    if (this.synth) {
      this.synth.cancel();
      this.isSpeaking = false;
      this.isPaused = false;
      this.currentUtterance = null;
    }
  }

  public getStatus(): { isSpeaking: boolean; isPaused: boolean } {
    return {
      isSpeaking: this.isSpeaking,
      isPaused: this.isPaused,
    };
  }
}

export const speechService = new SpeechNarrator();
