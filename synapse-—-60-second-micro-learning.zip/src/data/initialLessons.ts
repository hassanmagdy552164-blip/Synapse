import { Lesson } from '../types';

export const INITIAL_LESSONS: Lesson[] = [
  {
    id: 'lesson-glymphatic-system',
    title: "Why Sleep 'Flushes' Your Brain's Toxic Waste",
    tagline: 'The Discovery of the Glymphatic System in Slow-Wave Sleep',
    discipline: 'Neuroscience',
    durationSec: 60,
    coverImage: '/src/assets/images/lesson_neuroscience_1790604611939.jpg',
    publishedAt: '2 hours ago',
    mindSparks: 1420,
    savesCount: 689,
    difficulty: 'Intermediate',
    author: {
      id: 'author-elena',
      name: 'Dr. Elena Rostova',
      handle: '@elena_neuro',
      role: 'Associate Professor of Cellular Neuroscience',
      institution: 'University of Copenhagen',
      followersCount: 18400,
      lessonsCount: 34,
      verified: true,
    },
    beats: [
      {
        id: 'beat-1',
        startSec: 0,
        endSec: 14,
        title: 'The Enigma of Brain Metabolism',
        subtitle: 'Every organ has a lymphatic drainage system—except the brain. Or so we thought.',
        script: "Unlike the rest of your body, your brain has no lymphatic vessels to haul away metabolic junk. Yet it consumes twenty percent of your body's energy. How does it survive toxic accumulation?",
        bulletPoints: [
          'Brain consumes 20% of resting metabolic energy',
          'Generates daily cellular waste including Beta-Amyloid',
          'Lacks conventional peripheral lymphatic capillaries'
        ],
        diagramType: 'synapse'
      },
      {
        id: 'beat-2',
        startSec: 14,
        endSec: 32,
        title: 'The Glial Hydro-Pump (Aqp4)',
        subtitle: 'Cerebrospinal fluid surges through interstitial spaces.',
        script: "During deep slow-wave sleep, glial cells physically shrink by sixty percent! This opens microscopic floodgates where cerebrospinal fluid washes through tissue via Aquaporin-4 water channels.",
        bulletPoints: [
          'Glial cells contract by ~60% in slow-wave sleep',
          'Aquaporin-4 (Aqp4) water channels drive convective bulk flow',
          'Exchanges toxic interstitial solute directly into venous sinuses'
        ],
        keyFormulaOrConcept: 'CSF/ISF Exchange Rate: J = -K · ∇P',
        diagramType: 'synapse'
      },
      {
        id: 'beat-3',
        startSec: 32,
        endSec: 46,
        title: 'Amyloid & Tau Clearance',
        subtitle: 'Clearing precursors to neurodegeneration.',
        script: "This rapid hydraulic rinse removes toxic amyloid-beta and hyperphosphorylated tau proteins. Pulling an all-nighter leaves this cellular sewage stewing directly between your synapses.",
        bulletPoints: [
          'Beta-Amyloid clearance is ~2x faster asleep than awake',
          'Prevents chronic protein aggregations linked to Alzheimer’s',
          'Disrupted sleep directly impairs convective waste filtration'
        ],
        keyFormulaOrConcept: 'Clearance Ratio: Sleep / Wake ≈ 2.1x',
        diagramType: 'synapse'
      },
      {
        id: 'beat-4',
        startSec: 46,
        endSec: 60,
        title: 'Core Retention & Key Insight',
        subtitle: 'Sleep is not passive downtime—it is an active hydraulic flush.',
        script: "Sleep is not passive mental downtime. It is a vital biochemical power-wash. Guard your deep sleep stages to preserve neural architecture and cognitive clarity.",
        bulletPoints: [
          'Prioritize consistent slow-wave cycles (first 4 hours of night)',
          'Avoid alcohol before bed which suppresses restorative deep phases'
        ],
        keyFormulaOrConcept: 'Insight: Sleep is active mechanical filtration, not rest.',
        diagramType: 'synapse'
      }
    ],
    quiz: {
      question: 'What physical change occurs in glial cells during deep slow-wave sleep to enable fluid flow?',
      options: [
        'They expand to form a defensive insulating barrier',
        'They shrink by roughly 60%, expanding interstitial volume',
        'They multiply through rapid overnight mitosis',
        'They convert entirely into myelin sheaths'
      ],
      correctIndex: 1,
      explanation: 'Pioneered by Dr. Maiken Nedergaard, research shows glial cells contract by ~60% during slow-wave sleep, allowing cerebrospinal fluid to rush through the widened interstitial channels.'
    },
    keyTakeaway: 'The brain flushes metabolic proteins like amyloid-beta during sleep via the glymphatic system, driven by glial contraction and Aquaporin-4 channels.',
    citation: {
      title: 'Sleep Drives Metabolite Clearance from the Adult Brain',
      source: 'Science Journal (Vol 342, Issue 6156)',
      year: 2013,
      doiOrUrl: '10.1126/science.1241224'
    },
    comments: [
      {
        id: 'c1',
        authorName: 'Alex Mercer',
        authorHandle: '@amercer',
        timestamp: '45m ago',
        content: 'Feynman summary: Your brain builds up toxic exhaust all day. When you hit deep sleep, the brain cells shrink like sponges, letting CSF power-wash the debris out.',
        likes: 88,
        isFeynmanSummary: true
      },
      {
        id: 'c2',
        authorName: 'Dr. Nora Hayes',
        authorHandle: '@dr_hayes',
        timestamp: '1h ago',
        content: 'This explains why chronic insomnia is such a massive predictor of early cognitive decline. Truly brilliant 60-second condensation.',
        likes: 42
      }
    ]
  },
  {
    id: 'lesson-quantum-entanglement',
    title: "Quantum Entanglement Can't Send Faster-Than-Light Signals",
    tagline: 'The No-Communication Theorem Explained in 60 Seconds',
    discipline: 'Physics & Quantum',
    durationSec: 60,
    coverImage: '/src/assets/images/lesson_quantum_1790604625064.jpg',
    publishedAt: '5 hours ago',
    mindSparks: 2840,
    savesCount: 1120,
    difficulty: 'Advanced',
    author: {
      id: 'author-marcus',
      name: 'Marcus Thorne, PhD',
      handle: '@marcus_physics',
      role: 'Theoretical Physicist & Fellow',
      institution: 'Oxford Quantum Institute',
      followersCount: 31200,
      lessonsCount: 52,
      verified: true,
    },
    beats: [
      {
        id: 'beat-1',
        startSec: 0,
        endSec: 13,
        title: "Einstein's 'Spooky Action' Paradox",
        subtitle: 'If entangled states collapse instantaneously, why cannot we transmit Morse code?',
        script: "When you measure one entangled particle, the other collapses instantly across light-years. Popular science claims this enables instantaneous faster-than-light internet. It does not.",
        bulletPoints: [
          'Entangled Bell state: (|00⟩ + |11⟩) / √2',
          'Measurement collapses both states with zero time delay',
          'Seems to violate Special Relativity at first glance'
        ],
        diagramType: 'quantum'
      },
      {
        id: 'beat-2',
        startSec: 13,
        endSec: 32,
        title: 'Intrinsic Randomness (Born Rule)',
        subtitle: 'You cannot choose the state you measure.',
        script: "Here is the catch: quantum measurement outcomes are completely random. When Alice measures her spin, she gets 0 or 1 with 50 percent probability. She cannot force a 1 to signal Bob.",
        bulletPoints: [
          'Alice has zero control over her measurement outcome',
          'P(outcome = 0) = 0.5, P(outcome = 1) = 0.5',
          'Bob’s reduced density matrix remains completely invariant'
        ],
        keyFormulaOrConcept: 'Born Rule: P(x) = |⟨x|ψ⟩|²',
        diagramType: 'quantum'
      },
      {
        id: 'beat-3',
        startSec: 32,
        endSec: 47,
        title: 'The No-Communication Theorem',
        subtitle: "Bob's measurement looks like pure static until Alice calls him.",
        script: "To Bob, his particles always register pure noise. He cannot tell whether Alice measured hers or went to lunch! Only by comparing notes via light-speed radio do the correlations appear.",
        bulletPoints: [
          'Trace over Alice: ρ_Bob = Tr_Alice(ρ_AB) = I / 2',
          'Bob’s local state cannot be changed by Alice’s operations',
          'Requires a classical speed-of-light channel to extract correlation'
        ],
        keyFormulaOrConcept: 'Tr_A(U_A ⊗ I_B · ρ · U_A† ⊗ I_B) = Tr_A(ρ)',
        diagramType: 'quantum'
      },
      {
        id: 'beat-4',
        startSec: 47,
        endSec: 60,
        title: 'Retention: Correlation ≠ Communication',
        subtitle: 'Quantum mechanics respects Einstein’s cosmic speed limit c.',
        script: "Entanglement provides synchronized random numbers, not an instantaneous walkie-talkie. Correlation without communication protects causality and the speed of light.",
        bulletPoints: [
          'Causality is preserved: no information travels faster than c',
          'Entanglement enables quantum cryptography, not FTL signaling'
        ],
        keyFormulaOrConcept: 'Rule: Shared randomness ≠ transmitted information.',
        diagramType: 'quantum'
      }
    ],
    quiz: {
      question: 'Why can Alice not send a faster-than-light message to Bob using entangled particles?',
      options: [
        'Because quantum particles lose entanglement after 100 meters',
        'Because Alice cannot control her own random measurement outcome',
        'Because magnetic fields always disrupt the vacuum',
        'Because light is slowed down by gravitational waves'
      ],
      correctIndex: 1,
      explanation: 'Since Alice cannot force her measurement to be 0 or 1 (it is intrinsically probabilistic via Born rule), Bob only ever sees local 50/50 noise until Alice sends him her results at regular light speed.'
    },
    keyTakeaway: 'The No-Communication Theorem proves entanglement cannot send information faster than light because local measurements yield pure intrinsic randomness.',
    citation: {
      title: 'A Simple Proof of the No-Communication Theorem',
      source: 'Physical Review Letters / arXiv:quant-ph',
      year: 1993,
      doiOrUrl: '10.1103/PhysRevLett.70.1895'
    },
    comments: [
      {
        id: 'c3',
        authorName: 'Kavita Rao',
        authorHandle: '@kavita_q',
        timestamp: '2h ago',
        content: 'Feynman analog: Alice and Bob have sealed envelopes containing red or blue slips. Opening your envelope tells you what the other has, but you cannot change the slip to send a message.',
        likes: 124,
        isFeynmanSummary: true
      }
    ]
  },
  {
    id: 'lesson-decoy-effect',
    title: 'The Decoy Effect: How Menus Manipulate Your Rationality',
    tagline: 'Asymmetric Dominance in Behavioral Pricing',
    discipline: 'Behavioral Economics',
    durationSec: 60,
    coverImage: '/src/assets/images/lesson_economics_1790604636559.jpg',
    publishedAt: '8 hours ago',
    mindSparks: 1980,
    savesCount: 940,
    difficulty: 'Beginner',
    author: {
      id: 'author-aris',
      name: 'Prof. Aris Vance',
      handle: '@aris_decision',
      role: 'Professor of Behavioral Economics',
      institution: 'Stanford Graduate School of Business',
      followersCount: 24700,
      lessonsCount: 41,
      verified: true,
    },
    beats: [
      {
        id: 'beat-1',
        startSec: 0,
        endSec: 13,
        title: 'The Subscription Dilemma',
        subtitle: 'When The Economist offered a strange 3-tier price menu.',
        script: "In a famous experiment by Dan Ariely, The Economist offered Web-only for $59, Print-only for $125, and Print-plus-Web for $125. Why would anyone offer Print-only at the exact same price as the bundle?",
        bulletPoints: [
          'Option A: Web Only ($59)',
          'Option B: Print Only ($125) — The Decoy',
          'Option C: Print + Web Bundle ($125)'
        ],
        diagramType: 'decoy_pricing'
      },
      {
        id: 'beat-2',
        startSec: 13,
        endSec: 32,
        title: 'Asymmetric Dominance',
        subtitle: 'The decoy exists purely to be inferior to one option.',
        script: "Option B is an 'asymmetrically dominated decoy'. It is completely inferior to Option C, but comparable. Our human brains struggle to calculate absolute value, so we rely on immediate relative comparisons.",
        bulletPoints: [
          'Decoy (Print $125) makes Bundle (Print+Web $125) look like a steal',
          'Eliminates decision paralysis by giving an obvious winner',
          'Triggers the cognitive heuristic of perceived bargain'
        ],
        keyFormulaOrConcept: 'Choice shift: Bundle chosen by 84% (up from 32%)',
        diagramType: 'decoy_pricing'
      },
      {
        id: 'beat-3',
        startSec: 32,
        endSec: 46,
        title: 'The Experiment Results',
        subtitle: 'Removing the useless decoy radically dropped revenue by 43%.',
        script: "When Ariely removed the useless decoy, 68% of students chose the cheaper $59 option! Revenue plummeted. The decoy was never meant to be bought; it was a psychological anchor.",
        bulletPoints: [
          'With Decoy: 84% choose expensive Bundle, 16% choose Web',
          'Without Decoy: 68% choose cheap Web, only 32% choose Bundle',
          'A useless option drastically reversed customer preference'
        ],
        keyFormulaOrConcept: 'Decoy Revenue Boost: +43.2% per customer',
        diagramType: 'decoy_pricing'
      },
      {
        id: 'beat-4',
        startSec: 46,
        endSec: 60,
        title: 'Defensive Cognition',
        subtitle: 'How to shield yourself from menu architecture.',
        script: "Whenever you see three tiers—popcorn sizes, SaaS tiers, wine lists—ask yourself: Is the middle option a decoy designed to nudge me into the premium tier?",
        bulletPoints: [
          'Spot decoys: Look for options clearly inferior in 1 dimension',
          'Evaluate each tier strictly against your actual utility needs'
        ],
        keyFormulaOrConcept: 'Rule: Judge utility in isolation, not against a decoy.',
        diagramType: 'decoy_pricing'
      }
    ],
    quiz: {
      question: 'What is the true commercial purpose of an asymmetrically dominated decoy in pricing?',
      options: [
        'To sell the decoy item directly to high-margin clients',
        'To make the target premium product feel like an irresistible bargain by comparison',
        'To confuse customers so they abandon the purchase entirely',
        'To comply with government fair-trade pricing regulations'
      ],
      correctIndex: 1,
      explanation: 'The decoy is deliberately crafted to be slightly inferior to the target option, providing an easy cognitive benchmark that steers buyers directly into the higher-priced product.'
    },
    keyTakeaway: 'The Decoy Effect proves human preferences are malleable and context-dependent: adding an inferior alternative tilts decisions toward the target option.',
    citation: {
      title: 'Predictably Irrational: The Hidden Forces That Shape Our Decisions',
      source: 'HarperCollins Publishers',
      year: 2008,
      doiOrUrl: 'ISBN: 978-0061353239'
    },
    comments: [
      {
        id: 'c4',
        authorName: 'Clara Oswald',
        authorHandle: '@clara_design',
        timestamp: '3h ago',
        content: 'Movie theater popcorn is the classic real-world culprit: Small $6, Medium $8.50, Large $9. Everyone grabs the large feeling smart.',
        likes: 95
      }
    ]
  },
  {
    id: 'lesson-pantheon-concrete',
    title: 'The Self-Healing Concrete of the Roman Pantheon',
    tagline: 'Why a 2,000-Year-Old Unreinforced Dome Still Defies Gravity',
    discipline: 'Architectural History',
    durationSec: 60,
    coverImage: '/src/assets/images/lesson_architecture_1790604656429.jpg',
    publishedAt: '12 hours ago',
    mindSparks: 1650,
    savesCount: 810,
    difficulty: 'Intermediate',
    author: {
      id: 'author-sophia',
      name: 'Sophia Chen',
      handle: '@sophia_arch',
      role: 'Architectural Historian & Conservator',
      institution: 'Sapienza University of Rome',
      followersCount: 15300,
      lessonsCount: 28,
      verified: true,
    },
    beats: [
      {
        id: 'beat-1',
        startSec: 0,
        endSec: 14,
        title: 'The World’s Largest Unreinforced Dome',
        subtitle: '142 feet wide, 2,000 years old, zero rebar.',
        script: "Modern steel-reinforced concrete begins cracking and crumbling within fifty to one hundred years. Yet the Roman Pantheon has stood for nearly two millennia without a single gram of rebar.",
        bulletPoints: [
          'Span diameter: 43.3 meters (142 feet)',
          'Constructed ~125 AD under Emperor Hadrian',
          'Completely free of tensile steel rebar'
        ],
        diagramType: 'pantheon'
      },
      {
        id: 'beat-2',
        startSec: 14,
        endSec: 32,
        title: 'Graduated Aggregate Architecture',
        subtitle: 'Lighter stones as the dome ascends toward the sky.',
        script: "Roman engineers solved weight with an ingenious density gradient. At the base, they mixed heavy travertine. Mid-dome, lighter tuff stone. At the summit, featherweight volcanic pumice.",
        bulletPoints: [
          'Base: Dense Travertine & Pozzolana concrete',
          'Midsection: Porous Tuff rock aggregates',
          'Dome Apex: Ultra-light frothy volcanic pumice',
          'Stepped concentric rings redirect compressive thrust downward'
        ],
        keyFormulaOrConcept: 'Thickness: 6.4m at base → 1.2m at oculus',
        diagramType: 'pantheon'
      },
      {
        id: 'beat-3',
        startSec: 32,
        endSec: 46,
        title: 'Hot Mixing & Self-Healing Clasts',
        subtitle: 'MIT discovery of lime clast mineralization in 2023.',
        script: "Recent microscopic analysis revealed 'lime clasts'. Romans mixed quicklime at blistering temperatures. When water seeps into tiny microcracks today, it dissolves the lime, recrystallizing into calcium carbonate and sealing the cracks automatically!",
        bulletPoints: [
          'Hot-mixing quicklime (CaO) creates reactive lime clasts',
          'Rainwater intrusion triggers dissolution of calcium ions',
          'Spontaneous precipitation into CaCO3 seals cracks shut'
        ],
        keyFormulaOrConcept: 'Reaction: Ca(OH)2 + CO2 → CaCO3 + H2O',
        diagramType: 'pantheon'
      },
      {
        id: 'beat-4',
        startSec: 46,
        endSec: 60,
        title: 'Retention: Nature-Engineered Durability',
        subtitle: 'Ancient material chemistry meets compressive geometry.',
        script: "By combining pure compression geometry with self-healing pozzolanic chemistry, Rome created structures that grow stronger with age rather than weaker.",
        bulletPoints: [
          'Compressive geometry avoids tensile fracture points',
          'Chemical reactivity actively repairs seismic micro-fissures'
        ],
        keyFormulaOrConcept: 'Principle: Compression geometry + self-healing chemistry.',
        diagramType: 'pantheon'
      }
    ],
    quiz: {
      question: 'How does Roman concrete spontaneously repair micro-cracks over centuries?',
      options: [
        'Roman slaves continually injected volcanic wax into exterior seams',
        'Quicklime clasts dissolve upon water intrusion and recrystallize into calcium carbonate',
        'Subterranean magnetic minerals pull fractures back together',
        'Tree root systems secrete natural adhesives around the foundation'
      ],
      correctIndex: 1,
      explanation: 'Research led by MIT in 2023 showed that reactive lime clasts created by hot-mixing dissolve when rainwater enters microcracks and recrystallize into solid calcite, healing the structure.'
    },
    keyTakeaway: 'The Pantheon endures because Roman concrete combined graduated lightweight volcanic aggregates with hot-mixed quicklime clasts that chemically self-heal cracks.',
    citation: {
      title: 'Hot Mixing: Mechanistic Insights into the Durability of Ancient Roman Concrete',
      source: 'Science Advances (Vol 9, Issue 1)',
      year: 2023,
      doiOrUrl: '10.1126/sciadv.add1602'
    },
    comments: [
      {
        id: 'c5',
        authorName: 'Julian Brand',
        authorHandle: '@jbrand_eng',
        timestamp: '5h ago',
        content: 'Feynman breakdown: Modern concrete rots because inner steel rusts and expands. Roman concrete used compression-only geometry and built-in mineral glue that heals when it gets wet.',
        likes: 112,
        isFeynmanSummary: true
      }
    ]
  },
  {
    id: 'lesson-bloom-filters',
    title: 'How Bloom Filters Check Billions of Items in Zero Time',
    tagline: 'The Probabilistic Data Structure Powering Databases and CDNs',
    discipline: 'Algorithms & Systems',
    durationSec: 60,
    coverImage: '/src/assets/images/lesson_quantum_1790604625064.jpg',
    publishedAt: '1 day ago',
    mindSparks: 1310,
    savesCount: 720,
    difficulty: 'Advanced',
    author: {
      id: 'author-devlin',
      name: 'Devlin Kage',
      handle: '@devlin_sys',
      role: 'Principal Distributed Systems Architect',
      institution: 'Systems Research Lab',
      followersCount: 19800,
      lessonsCount: 22,
      verified: true,
    },
    beats: [
      {
        id: 'beat-1',
        startSec: 0,
        endSec: 14,
        title: 'The Disk Seek Bottleneck',
        subtitle: 'Checking if a username or URL exists without melting your database.',
        script: "Imagine you have 10 billion database records on disk. Doing a disk seek for every web request creates catastrophic lag. What if you had a 5-megabyte bit array that could tell you if an item definitely DOES NOT exist?",
        bulletPoints: [
          'Disk I/O is 100,000x slower than RAM access',
          '99% of web requests query non-existent keys (bots/crawlers)',
          'Need a lightning-fast memory gatekeeper'
        ],
        diagramType: 'bloom_filter'
      },
      {
        id: 'beat-2',
        startSec: 14,
        endSec: 32,
        title: 'Hash Functions & Bit Arrays',
        subtitle: 'Setting k bits across an m-sized bit array.',
        script: "A Bloom Filter starts with a bit array of zeros. To insert a word, you hash it with three independent hash functions and flip those three bit positions to 1. No text is stored—only bits!",
        bulletPoints: [
          'Bit array of length m, initialized to all 0s',
          'Pass input x through k hash functions: h₁(x), h₂(x), h₃(x)',
          'Flip the resulting indices in the bit array to 1',
          'Space required: ~10 bits per element for a 1% error rate'
        ],
        keyFormulaOrConcept: 'Memory: ~1.2 bytes per item vs hundreds of bytes',
        diagramType: 'bloom_filter'
      },
      {
        id: 'beat-3',
        startSec: 32,
        endSec: 46,
        title: 'The Asymmetric Guarantee',
        subtitle: 'Zero false negatives, but possible false positives.',
        script: "To query: hash the item. If ANY of the three bits is zero, the item is GUARANTEED not in the database! Zero false negatives. If all three bits are 1, it MIGHT be there, so you safely query disk.",
        bulletPoints: [
          'If any hᵢ(x) == 0: 100% guarantee NOT present (skip disk!)',
          'If all hᵢ(x) == 1: Probably present (run disk lookup)',
          'Eliminates 99% of expensive disk lookups with tiny RAM footprint'
        ],
        keyFormulaOrConcept: 'False Positive Rate: ε ≈ (1 - e^(-kn/m))^k',
        diagramType: 'bloom_filter'
      },
      {
        id: 'beat-4',
        startSec: 46,
        endSec: 60,
        title: 'Retention: Probabilistic Efficiency',
        subtitle: 'Trading a tiny error rate for massive speed and memory savings.',
        script: "Used by Google Chrome for malicious URLs, Cassandra databases, and Ethereum nodes. When scale is massive, probabilistic answers beat deterministic brute force every time.",
        bulletPoints: [
          'Chrome checks malicious URL bloom filter locally before pinging server',
          'LSM tree engines (RocksDB, Cassandra) use it for lightning reads'
        ],
        keyFormulaOrConcept: 'Tradeoff: Accepts false positives to gain zero false negatives.',
        diagramType: 'bloom_filter'
      }
    ],
    quiz: {
      question: 'Which of the following is an absolute mathematical guarantee of a standard Bloom Filter?',
      options: [
        'It has zero false positives',
        'It can tell you the original string that was stored',
        'It has zero false negatives: if it says an item is not present, it definitely is not',
        'You can easily delete individual items without rebuilding'
      ],
      correctIndex: 2,
      explanation: 'A Bloom filter guarantees zero false negatives: if any corresponding bit in the array is 0, the item could never have been inserted.'
    },
    keyTakeaway: 'Bloom filters use hash functions on bit arrays to instantly reject non-existent queries with zero false negatives and microsecond RAM speed.',
    citation: {
      title: 'Space/Time Trade-offs in Hash Coding with Allowable Errors',
      source: 'Communications of the ACM (Vol 13, Issue 7)',
      year: 1970,
      doiOrUrl: '10.1145/362686.362692'
    },
    comments: [
      {
        id: 'c6',
        authorName: 'Sanjay Patel',
        authorHandle: '@spatel_dev',
        timestamp: '1d ago',
        content: 'The most elegant data structure ever created. 60 seconds captures the exact intuition without getting bogged down in math.',
        likes: 67
      }
    ]
  },
  {
    id: 'lesson-ship-of-theseus',
    title: 'The Ship of Theseus: The Paradox of Changing Identity',
    tagline: 'When Every Plank is Replaced, Are You Still You?',
    discipline: 'Philosophy & Logic',
    durationSec: 60,
    coverImage: '/src/assets/images/lesson_economics_1790604636559.jpg',
    publishedAt: '2 days ago',
    mindSparks: 1180,
    savesCount: 540,
    difficulty: 'Beginner',
    author: {
      id: 'author-marcus',
      name: 'Marcus Thorne, PhD',
      handle: '@marcus_physics',
      role: 'Theoretical Physicist & Fellow',
      institution: 'Oxford Quantum Institute',
      followersCount: 31200,
      lessonsCount: 52,
      verified: true,
    },
    beats: [
      {
        id: 'beat-1',
        startSec: 0,
        endSec: 14,
        title: 'The Voyage of Plutarch',
        subtitle: 'An ancient thought experiment recorded in 75 AD.',
        script: "Theseus returns from Crete in a wooden ship. Over decades, as each wooden plank rots, the Athenians replace it with fresh timber until eventually, not a single original molecule remains.",
        bulletPoints: [
          'Documented by Greek historian Plutarch',
          'Every timber, nail, and rope is gradually swapped',
          'The shape and function remain unchanged'
        ],
        diagramType: 'theseus'
      },
      {
        id: 'beat-2',
        startSec: 14,
        endSec: 32,
        title: "Hobbes' Scavenger Complication",
        subtitle: 'What if someone hoards the rotting planks and rebuilds them?',
        script: "Philosopher Thomas Hobbes added a wicked twist: Suppose a scavenger collects all the rotted planks and rebuilds the exact ship in drydock. Now you have two ships! Which one is the TRUE Ship of Theseus?",
        bulletPoints: [
          'Ship A: The continuously maintained ship with all-new planks',
          'Ship B: Reconstructed from the discarded original timbers',
          'Challenges Spatio-Temporal Continuity vs Material Identity'
        ],
        keyFormulaOrConcept: 'Contradiction: If A = Theseus and B = Theseus, then A = B.',
        diagramType: 'theseus'
      },
      {
        id: 'beat-3',
        startSec: 32,
        endSec: 46,
        title: 'You Are The Ship',
        subtitle: 'Every 7 to 10 years, almost all your bodily cells are replaced.',
        script: "This isn't an abstract Greek puzzle—it is YOU. Almost every cell in your body, from your skin to your gut lining, is completely replaced every decade. Your atoms are not permanent; only the dynamic pattern persists.",
        bulletPoints: [
          'Red blood cells live ~120 days; stomach lining replaces every 5 days',
          'Identity is a process and informational configuration, not static matter'
        ],
        keyFormulaOrConcept: 'Insight: You are a standing wave, not a static stone.',
        diagramType: 'theseus'
      },
      {
        id: 'beat-4',
        startSec: 46,
        endSec: 60,
        title: 'Retention: Identity as Information Flow',
        subtitle: 'Continuity of consciousness and relational patterns.',
        script: "Modern cognitive science views identity as an emergent software program running on constantly renewing biological hardware. Identity is a pattern, not a substance.",
        bulletPoints: [
          'Four-dimensionalism: objects have temporal parts extending through time',
          'Memory and narrative continuity anchor selfhood'
        ],
        keyFormulaOrConcept: 'Takeaway: Identity is structural information in motion.',
        diagramType: 'theseus'
      }
    ],
    quiz: {
      question: 'What biological reality directly reflects the Ship of Theseus paradox in human beings?',
      options: [
        'Humans only use 10% of their brain capacity',
        'Nearly all human cellular matter is recycled and replaced throughout life',
        'DNA sequences change completely with each season',
        'Brain neurons duplicate twice every single year'
      ],
      correctIndex: 1,
      explanation: 'Our cells continuously die and are replaced by fresh matter from the food we consume; our physical identity relies on the continuity of the pattern, not immutable atoms.'
    },
    keyTakeaway: 'The Ship of Theseus demonstrates that enduring identity is governed by organizational continuity and informational pattern rather than the physical matter itself.',
    citation: {
      title: 'Life of Theseus (Parallel Lives)',
      source: 'Plutarch / Oxford Classical Texts',
      year: 75,
      doiOrUrl: 'Perseus Digital Library 1.23.1'
    },
    comments: [
      {
        id: 'c7',
        authorName: 'Talia Ross',
        authorHandle: '@talia_phil',
        timestamp: '1d ago',
        content: 'Alan Watts said it best: "You are a whirlpool in a river." The water molecules rush through, but the whirlpool pattern remains. Superb lesson!',
        likes: 148,
        isFeynmanSummary: true
      }
    ]
  }
];
