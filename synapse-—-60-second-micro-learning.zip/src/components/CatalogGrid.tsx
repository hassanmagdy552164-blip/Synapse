import React, { useState, useMemo } from 'react';
import { Lesson, Discipline } from '../types';
import { LessonCard } from './LessonCard';

interface CatalogGridProps {
  lessons: Lesson[];
  savedLessonIds: string[];
  likedLessonIds: string[];
  onPlayLesson: (lesson: Lesson) => void;
  onToggleSave: (lessonId: string) => void;
  onToggleLike: (lessonId: string) => void;
  onSelectAuthor: (authorId: string) => void;
  onOpenStudio: () => void;
}

const DISCIPLINES: Discipline[] = [
  'All',
  'Neuroscience',
  'Physics & Quantum',
  'Behavioral Economics',
  'Architectural History',
  'Algorithms & Systems',
  'Philosophy & Logic',
];

export const CatalogGrid: React.FC<CatalogGridProps> = ({
  lessons,
  savedLessonIds,
  likedLessonIds,
  onPlayLesson,
  onToggleSave,
  onToggleLike,
  onSelectAuthor,
  onOpenStudio,
}) => {
  const [selectedDiscipline, setSelectedDiscipline] = useState<Discipline>('All');
  const [searchQuery, setSearchQuery] = useState('');
  const [difficultyFilter, setDifficultyFilter] = useState<'All' | 'Beginner' | 'Intermediate' | 'Advanced'>('All');
  const [sortBy, setSortBy] = useState<'popular' | 'recent' | 'saved'>('popular');

  const filteredLessons = useMemo(() => {
    return lessons
      .filter((l) => {
        if (selectedDiscipline !== 'All' && l.discipline !== selectedDiscipline) {
          return false;
        }
        if (difficultyFilter !== 'All' && l.difficulty !== difficultyFilter) {
          return false;
        }
        if (searchQuery.trim()) {
          const q = searchQuery.toLowerCase();
          const matchTitle = l.title.toLowerCase().includes(q);
          const matchTagline = l.tagline.toLowerCase().includes(q);
          const matchAuthor = l.author.name.toLowerCase().includes(q);
          const matchTakeaway = l.keyTakeaway.toLowerCase().includes(q);
          if (!matchTitle && !matchTagline && !matchAuthor && !matchTakeaway) {
            return false;
          }
        }
        return true;
      })
      .sort((a, b) => {
        if (sortBy === 'popular') return b.mindSparks - a.mindSparks;
        if (sortBy === 'saved') return b.savesCount - a.savesCount;
        return 0; // Default order
      });
  }, [lessons, selectedDiscipline, difficultyFilter, searchQuery, sortBy]);

  return (
    <div className="w-full max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 flex flex-col gap-6">
      {/* Editorial Header / Proposition */}
      <div className="flex flex-col md:flex-row md:items-end justify-between gap-4 pb-6 border-b border-slate-800">
        <div className="max-w-2xl">
          <div className="text-xs uppercase tracking-wider text-cyan-400 font-mono font-medium mb-1">
            Curated Knowledge Feed
          </div>
          <h1 className="text-2xl sm:text-3xl font-serif font-bold text-slate-100 tracking-tight leading-tight">
            60-Second Intellectual Revolutions
          </h1>
          <p className="text-sm text-slate-400 mt-1.5 leading-relaxed">
            Every post delivers an atomic mental model with causal mechanisms, peer-reviewed citations, and instant retention checks. No entertainment fillers.
          </p>
        </div>

        <div className="flex items-center gap-3 shrink-0">
          <button
            type="button"
            onClick={onOpenStudio}
            className="px-4 py-2 bg-cyan-600 hover:bg-cyan-500 text-white text-xs font-semibold rounded-xl shadow-lg shadow-cyan-600/20 transition-all hover:scale-[1.02] active:scale-[0.98] whitespace-nowrap"
          >
            + Post 60s Lesson
          </button>
        </div>
      </div>

      {/* Filter Toolbar */}
      <div className="flex flex-col gap-3">
        {/* Discipline Segmented Tabs */}
        <div className="flex items-center gap-1.5 overflow-x-auto pb-1 scrollbar-none">
          {DISCIPLINES.map((discipline) => (
            <button
              key={discipline}
              type="button"
              onClick={() => setSelectedDiscipline(discipline)}
              className={`px-3 py-1.5 text-xs font-medium rounded-lg transition-colors whitespace-nowrap shrink-0 ${
                selectedDiscipline === discipline
                  ? 'bg-slate-800 text-cyan-300 shadow-sm border border-slate-700'
                  : 'text-slate-400 hover:text-slate-200 hover:bg-slate-900/60'
              }`}
            >
              {discipline}
            </button>
          ))}
        </div>

        {/* Search & Secondary Filter Bar */}
        <div className="flex flex-col sm:flex-row items-center justify-between gap-3 pt-1">
          {/* Search box */}
          <div className="relative w-full sm:max-w-md">
            <span className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-500 text-xs">
              🔍
            </span>
            <input
              type="text"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              placeholder="Search concepts, mechanisms, authors, papers..."
              className="w-full bg-slate-900/80 border border-slate-800 rounded-xl pl-8 pr-4 py-2 text-xs text-slate-200 placeholder-slate-500 focus:outline-none focus:border-cyan-500 transition-colors"
            />
            {searchQuery && (
              <button
                type="button"
                onClick={() => setSearchQuery('')}
                className="absolute right-3 top-1/2 -translate-y-1/2 text-slate-500 hover:text-slate-300 text-xs"
              >
                ✕
              </button>
            )}
          </div>

          {/* Difficulty & Sort Controls */}
          <div className="flex items-center gap-3 w-full sm:w-auto justify-end text-xs">
            <div className="flex items-center gap-1.5 text-slate-400">
              <span className="text-[11px] font-mono">Difficulty:</span>
              <select
                value={difficultyFilter}
                onChange={(e) => setDifficultyFilter(e.target.value as any)}
                className="bg-slate-900 border border-slate-800 rounded-lg px-2.5 py-1 text-xs text-slate-200 focus:outline-none focus:border-cyan-500"
              >
                <option value="All">All Levels</option>
                <option value="Beginner">Beginner</option>
                <option value="Intermediate">Intermediate</option>
                <option value="Advanced">Advanced</option>
              </select>
            </div>

            <div className="flex items-center gap-1.5 text-slate-400">
              <span className="text-[11px] font-mono">Sort:</span>
              <select
                value={sortBy}
                onChange={(e) => setSortBy(e.target.value as any)}
                className="bg-slate-900 border border-slate-800 rounded-lg px-2.5 py-1 text-xs text-slate-200 focus:outline-none focus:border-cyan-500"
              >
                <option value="popular">Most Mind Sparks</option>
                <option value="saved">Most Saved</option>
                <option value="recent">Latest Research</option>
              </select>
            </div>
          </div>
        </div>
      </div>

      {/* Grid of Lessons */}
      {filteredLessons.length > 0 ? (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 pt-2">
          {filteredLessons.map((lesson) => (
            <LessonCard
              key={lesson.id}
              lesson={lesson}
              isSaved={savedLessonIds.includes(lesson.id)}
              isLiked={likedLessonIds.includes(lesson.id)}
              onPlay={onPlayLesson}
              onToggleSave={onToggleSave}
              onToggleLike={onToggleLike}
              onSelectAuthor={onSelectAuthor}
            />
          ))}
        </div>
      ) : (
        <div className="py-20 flex flex-col items-center justify-center text-center p-6 bg-slate-900/40 rounded-3xl border border-slate-800">
          <div className="w-12 h-12 rounded-2xl bg-slate-800/80 text-cyan-400 flex items-center justify-center font-mono text-xl mb-3">
            00
          </div>
          <h3 className="text-base font-serif font-bold text-slate-200">
            No Micro-Lessons Found
          </h3>
          <p className="text-xs text-slate-400 max-w-sm mt-1 mb-4">
            Try adjusting your search keywords or discipline filters, or author the first 60-second lesson in this topic.
          </p>
          <button
            type="button"
            onClick={() => {
              setSearchQuery('');
              setSelectedDiscipline('All');
              setDifficultyFilter('All');
            }}
            className="px-4 py-2 bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs rounded-xl transition-colors"
          >
            Reset Filters
          </button>
        </div>
      )}
    </div>
  );
};
