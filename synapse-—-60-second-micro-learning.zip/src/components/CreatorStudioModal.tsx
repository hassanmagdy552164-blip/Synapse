import React, { useState } from 'react';
import { Lesson, Discipline, SlideBeat } from '../types';
import { speechService } from '../services/speech';

interface CreatorStudioModalProps {
  isOpen: boolean;
  onClose: () => void;
  onPublish: (newLesson: Lesson) => void;
}

const DISCIPLINES: Discipline[] = [
  'Neuroscience',
  'Physics & Quantum',
  'Behavioral Economics',
  'Architectural History',
  'Algorithms & Systems',
  'Philosophy & Logic',
];

export const CreatorStudioModal: React.FC<CreatorStudioModalProps> = ({
  isOpen,
  onClose,
  onPublish,
}) => {
  const [title, setTitle] = useState('');
  const [tagline, setTagline] = useState('');
  const [discipline, setDiscipline] = useState<Discipline>('Neuroscience');
  const [difficulty, setDifficulty] = useState<'Beginner' | 'Intermediate' | 'Advanced'>('Intermediate');
  const [authorName, setAuthorName] = useState('Dr. Alex Reed');
  const [authorInstitution, setAuthorInstitution] = useState('Cognitive Science Lab');

  // 4 Beats
  const [b1Title, setB1Title] = useState('The Counter-Intuitive Hook');
  const [b1Script, setB1Script] = useState('Most people assume memory works like a video recording, but neuroscience shows our brains reconstruct every single recall from scratch.');

  const [b2Title, setB2Title] = useState('The Molecular Mechanism');
  const [b2Script, setB2Script] = useState('During reconsolidation, synaptic proteins temporarily destabilize. Every time you bring up a past memory, you literally open it in edit mode before saving.');
  const [b2Concept, setB2Concept] = useState('Mechanism: Protein Synthesis Blockade (Anisomycin Effect)');

  const [b3Title, setB3Title] = useState('The Clinical Proof');
  const [b3Script, setB3Script] = useState('Clinical trials with propranolol prove that administering a beta-blocker during memory recall erases the physiological fear response while preserving the factual narrative.');

  const [b4Title, setB4Title] = useState('Core Retention & Rule');
  const [b4Script, setB4Script] = useState('Your memories are not stone engravings; they are living clay molded by your present emotional state. Guard the context in which you recall painful events.');
  const [b4Takeaway, setB4Takeaway] = useState('Memories are reconstructed dynamically upon each recall through protein synthesis, not replayed statically.');

  // Quiz
  const [quizQuestion, setQuizQuestion] = useState('What occurs biologically when a human memory is recalled?');
  const [quizOptions, setQuizOptions] = useState([
    'The synaptic pathways become permanently read-only',
    'The memory temporarily destabilizes and requires protein synthesis to reconsolidate',
    'The memory is duplicated to the cerebellum',
    'Old memories are deleted after 48 hours'
  ]);
  const [correctOptionIdx, setCorrectOptionIdx] = useState(1);
  const [quizExplanation, setQuizExplanation] = useState('Memories undergo reconsolidation: recalling a memory renders it labile and plastic, requiring fresh protein synthesis to be stored again.');

  // Citation
  const [citeTitle, setCiteTitle] = useState('Memory Reconsolidation: From Synapse to Clinical Application');
  const [citeSource, setCiteSource] = useState('Nature Reviews Neuroscience');
  const [citeYear, setCiteYear] = useState('2021');

  // Narration test state
  const [isTestingAudio, setIsTestingAudio] = useState(false);

  if (!isOpen) return null;

  // Calculate word count & estimated duration
  const totalWords = [b1Script, b2Script, b3Script, b4Script]
    .join(' ')
    .trim()
    .split(/\s+/)
    .filter(Boolean).length;

  // Approx 135 words = 60s at 135 words/min
  const estimatedSec = Math.round((totalWords / 135) * 60);

  const handleTestAudio = () => {
    if (isTestingAudio) {
      speechService.stop();
      setIsTestingAudio(false);
      return;
    }

    const fullScript = `${b1Script} ... ${b2Script} ... ${b3Script} ... ${b4Script}`;
    setIsTestingAudio(true);
    speechService.speak(fullScript, () => {
      setIsTestingAudio(false);
    });
  };

  const handlePublish = (e: React.FormEvent) => {
    e.preventDefault();
    speechService.stop();

    const beats: SlideBeat[] = [
      {
        id: 'beat-1',
        startSec: 0,
        endSec: 14,
        title: b1Title,
        subtitle: 'The 15-Second Counter-Intuitive Hook',
        script: b1Script,
        bulletPoints: [
          'Exposes common cognitive misconceptions',
          'Establishes the core problem statement'
        ],
        diagramType: 'custom',
      },
      {
        id: 'beat-2',
        startSec: 14,
        endSec: 32,
        title: b2Title,
        subtitle: 'The Exact Causal Mechanism',
        script: b2Script,
        bulletPoints: [
          'Step-by-step causal chain breakdown',
          'Biochemical / mathematical structure'
        ],
        keyFormulaOrConcept: b2Concept,
        diagramType: 'custom',
      },
      {
        id: 'beat-3',
        startSec: 32,
        endSec: 46,
        title: b3Title,
        subtitle: 'Empirical Evidence & Experiment',
        script: b3Script,
        bulletPoints: [
          'Peer-reviewed experimental verification',
          'Real-world operational consequence'
        ],
        diagramType: 'custom',
      },
      {
        id: 'beat-4',
        startSec: 46,
        endSec: 60,
        title: b4Title,
        subtitle: '60s Retention & Mental Model',
        script: b4Script,
        bulletPoints: [
          'Actionable lifelong intuition',
          'Shield against cognitive errors'
        ],
        keyFormulaOrConcept: b4Takeaway,
        diagramType: 'custom',
      },
    ];

    const newLesson: Lesson = {
      id: 'lesson-' + Date.now(),
      title: title.trim() || 'The Dynamic Plasticity of Human Memory',
      tagline: tagline.trim() || 'Why Every Recall Is A Rewrite',
      discipline,
      durationSec: 60,
      publishedAt: 'Just now',
      mindSparks: 1,
      savesCount: 0,
      difficulty,
      coverImage: '/src/assets/images/lesson_neuroscience_1790604611939.jpg',
      author: {
        id: 'author-' + Date.now(),
        name: authorName.trim() || 'Dr. Alex Reed',
        handle: '@' + (authorName.toLowerCase().replace(/\s+/g, '_') || 'alex_reed'),
        role: 'Research Fellow',
        institution: authorInstitution.trim() || 'Cognitive Science Lab',
        followersCount: 1,
        lessonsCount: 1,
        verified: true,
      },
      beats,
      quiz: {
        question: quizQuestion,
        options: quizOptions,
        correctIndex: correctOptionIdx,
        explanation: quizExplanation,
      },
      keyTakeaway: b4Takeaway,
      citation: {
        title: citeTitle,
        source: citeSource,
        year: parseInt(citeYear, 10) || 2024,
      },
      comments: [],
    };

    onPublish(newLesson);
    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm animate-fade-in">
      <div className="w-full max-w-3xl bg-slate-900 border border-slate-800 rounded-3xl overflow-hidden shadow-2xl flex flex-col max-h-[92vh]">
        {/* Header */}
        <div className="p-5 border-b border-slate-800 flex items-center justify-between bg-slate-950/60">
          <div>
            <div className="text-xs uppercase tracking-wider text-cyan-400 font-mono font-medium">
              The 60-Second Academy Studio
            </div>
            <h2 className="text-lg font-serif font-bold text-slate-100">
              Compose an Atomic Micro-Lesson
            </h2>
          </div>

          {/* 60s Word Budget Tracker */}
          <div className="flex items-center gap-3">
            <div className="text-right">
              <div
                className={`text-xs font-mono font-bold ${
                  estimatedSec > 62
                    ? 'text-rose-400'
                    : estimatedSec < 45
                    ? 'text-amber-400'
                    : 'text-emerald-400'
                }`}
              >
                ~{estimatedSec}s ({totalWords} words)
              </div>
              <div className="text-[10px] text-slate-400">
                {estimatedSec > 60
                  ? 'Exceeds 60s limit!'
                  : estimatedSec < 45
                  ? 'Add more depth'
                  : 'Perfect 60s pacing'}
              </div>
            </div>

            <button
              type="button"
              onClick={onClose}
              className="w-8 h-8 rounded-full bg-slate-800 text-slate-400 hover:text-white flex items-center justify-center text-sm"
            >
              ✕
            </button>
          </div>
        </div>

        {/* Scrollable Form Body */}
        <form onSubmit={handlePublish} className="flex-1 overflow-y-auto p-6 flex flex-col gap-6">
          {/* Metadata Section */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div>
              <label className="block text-xs font-medium text-slate-300 mb-1">
                Lesson Title (The Core Question)
              </label>
              <input
                type="text"
                required
                value={title}
                onChange={(e) => setTitle(e.target.value)}
                placeholder="e.g. Why Sleep Flushes Your Brain's Waste"
                className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3 py-2 text-xs text-slate-100 focus:outline-none focus:border-cyan-500"
              />
            </div>

            <div>
              <label className="block text-xs font-medium text-slate-300 mb-1">
                Tagline / Scientific Hook
              </label>
              <input
                type="text"
                required
                value={tagline}
                onChange={(e) => setTagline(e.target.value)}
                placeholder="e.g. The Discovery of the Glymphatic System"
                className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3 py-2 text-xs text-slate-100 focus:outline-none focus:border-cyan-500"
              />
            </div>

            <div>
              <label className="block text-xs font-medium text-slate-300 mb-1">
                Academic Discipline
              </label>
              <select
                value={discipline}
                onChange={(e) => setDiscipline(e.target.value as Discipline)}
                className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3 py-2 text-xs text-slate-100 focus:outline-none focus:border-cyan-500"
              >
                {DISCIPLINES.map((d) => (
                  <option key={d} value={d}>
                    {d}
                  </option>
                ))}
              </select>
            </div>

            <div>
              <label className="block text-xs font-medium text-slate-300 mb-1">
                Cognitive Difficulty
              </label>
              <div className="flex gap-2">
                {(['Beginner', 'Intermediate', 'Advanced'] as const).map((lvl) => (
                  <button
                    key={lvl}
                    type="button"
                    onClick={() => setDifficulty(lvl)}
                    className={`flex-1 py-1.5 text-xs font-medium rounded-xl border transition-colors ${
                      difficulty === lvl
                        ? 'bg-cyan-950 border-cyan-500 text-cyan-200'
                        : 'bg-slate-950 border-slate-800 text-slate-400 hover:text-slate-200'
                    }`}
                  >
                    {lvl}
                  </button>
                ))}
              </div>
            </div>
          </div>

          {/* 4 Beats Timeline Blueprint */}
          <div className="flex flex-col gap-3">
            <div className="flex items-center justify-between border-b border-slate-800 pb-2">
              <span className="text-xs uppercase tracking-wider text-slate-300 font-mono font-medium">
                The 4-Beat 60-Second Timeline
              </span>
              <span className="text-[11px] text-cyan-400 font-mono">
                Exact 15s Segments
              </span>
            </div>

            {/* Beat 1: Hook */}
            <div className="p-4 bg-slate-950/70 border border-slate-800 rounded-2xl flex flex-col gap-2">
              <div className="flex items-center justify-between text-xs font-mono text-cyan-400">
                <span>BEAT 1 (0s - 14s) · THE COUNTER-INTUITIVE HOOK</span>
                <span>~30 words</span>
              </div>
              <input
                type="text"
                value={b1Title}
                onChange={(e) => setB1Title(e.target.value)}
                placeholder="Beat 1 Title"
                className="bg-slate-900 border border-slate-800 rounded-lg px-2.5 py-1.5 text-xs text-slate-200"
              />
              <textarea
                rows={2}
                value={b1Script}
                onChange={(e) => setB1Script(e.target.value)}
                placeholder="Hook script spoken aloud..."
                className="bg-slate-900 border border-slate-800 rounded-lg p-2.5 text-xs text-slate-200 resize-none font-sans"
              />
            </div>

            {/* Beat 2: Mechanism */}
            <div className="p-4 bg-slate-950/70 border border-slate-800 rounded-2xl flex flex-col gap-2">
              <div className="flex items-center justify-between text-xs font-mono text-indigo-400">
                <span>BEAT 2 (14s - 32s) · THE CAUSAL MECHANISM</span>
                <span>~40 words</span>
              </div>
              <input
                type="text"
                value={b2Title}
                onChange={(e) => setB2Title(e.target.value)}
                placeholder="Beat 2 Title"
                className="bg-slate-900 border border-slate-800 rounded-lg px-2.5 py-1.5 text-xs text-slate-200"
              />
              <textarea
                rows={2}
                value={b2Script}
                onChange={(e) => setB2Script(e.target.value)}
                placeholder="Mechanism script..."
                className="bg-slate-900 border border-slate-800 rounded-lg p-2.5 text-xs text-slate-200 resize-none font-sans"
              />
              <input
                type="text"
                value={b2Concept}
                onChange={(e) => setB2Concept(e.target.value)}
                placeholder="Key Formula / Mechanism Rule (e.g. Rate = -K * dP)"
                className="bg-slate-900/80 border border-slate-800 rounded-lg px-2.5 py-1 text-[11px] font-mono text-indigo-300"
              />
            </div>

            {/* Beat 3: Evidence */}
            <div className="p-4 bg-slate-950/70 border border-slate-800 rounded-2xl flex flex-col gap-2">
              <div className="flex items-center justify-between text-xs font-mono text-amber-400">
                <span>BEAT 3 (32s - 46s) · EMPIRICAL PROOF & REAL DATA</span>
                <span>~35 words</span>
              </div>
              <input
                type="text"
                value={b3Title}
                onChange={(e) => setB3Title(e.target.value)}
                placeholder="Beat 3 Title"
                className="bg-slate-900 border border-slate-800 rounded-lg px-2.5 py-1.5 text-xs text-slate-200"
              />
              <textarea
                rows={2}
                value={b3Script}
                onChange={(e) => setB3Script(e.target.value)}
                placeholder="Evidence and experiment..."
                className="bg-slate-900 border border-slate-800 rounded-lg p-2.5 text-xs text-slate-200 resize-none font-sans"
              />
            </div>

            {/* Beat 4: Retention */}
            <div className="p-4 bg-slate-950/70 border border-slate-800 rounded-2xl flex flex-col gap-2">
              <div className="flex items-center justify-between text-xs font-mono text-emerald-400">
                <span>BEAT 4 (46s - 60s) · RETENTION TAKEAWAY & QUIZ TRIGGER</span>
                <span>~30 words</span>
              </div>
              <input
                type="text"
                value={b4Title}
                onChange={(e) => setB4Title(e.target.value)}
                placeholder="Beat 4 Title"
                className="bg-slate-900 border border-slate-800 rounded-lg px-2.5 py-1.5 text-xs text-slate-200"
              />
              <textarea
                rows={2}
                value={b4Script}
                onChange={(e) => setB4Script(e.target.value)}
                placeholder="Final takeaway..."
                className="bg-slate-900 border border-slate-800 rounded-lg p-2.5 text-xs text-slate-200 resize-none font-sans"
              />
              <input
                type="text"
                value={b4Takeaway}
                onChange={(e) => setB4Takeaway(e.target.value)}
                placeholder="1-sentence core mental model to remember forever"
                className="bg-slate-900/80 border border-slate-800 rounded-lg px-2.5 py-1 text-[11px] font-sans text-emerald-300"
              />
            </div>
          </div>

          {/* Retention Quiz Authoring */}
          <div className="p-4 bg-slate-950/70 border border-slate-800 rounded-2xl flex flex-col gap-3">
            <div className="text-xs uppercase tracking-wider text-slate-300 font-mono font-medium">
              60s Concept Check Question (Instant Test)
            </div>

            <div>
              <label className="block text-[11px] text-slate-400 mb-1">Question Prompt</label>
              <input
                type="text"
                value={quizQuestion}
                onChange={(e) => setQuizQuestion(e.target.value)}
                className="w-full bg-slate-900 border border-slate-800 rounded-lg px-3 py-1.5 text-xs text-slate-200"
              />
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-2">
              {quizOptions.map((opt, i) => (
                <div key={i} className="flex items-center gap-2">
                  <input
                    type="radio"
                    name="correct_choice"
                    checked={correctOptionIdx === i}
                    onChange={() => setCorrectOptionIdx(i)}
                    className="accent-cyan-500"
                  />
                  <input
                    type="text"
                    value={opt}
                    onChange={(e) => {
                      const next = [...quizOptions];
                      next[i] = e.target.value;
                      setQuizOptions(next);
                    }}
                    placeholder={`Option ${String.fromCharCode(65 + i)}`}
                    className="flex-1 bg-slate-900 border border-slate-800 rounded-lg px-2.5 py-1 text-xs text-slate-200"
                  />
                </div>
              ))}
            </div>

            <div>
              <label className="block text-[11px] text-slate-400 mb-1">Scientific Explanation</label>
              <textarea
                rows={2}
                value={quizExplanation}
                onChange={(e) => setQuizExplanation(e.target.value)}
                placeholder="Explain why the correct answer is true..."
                className="w-full bg-slate-900 border border-slate-800 rounded-lg p-2 text-xs text-slate-200 resize-none font-sans"
              />
            </div>
          </div>

          {/* Academic Literature Verification */}
          <div className="p-4 bg-slate-950/70 border border-slate-800 rounded-2xl grid grid-cols-1 md:grid-cols-3 gap-3">
            <div className="md:col-span-2">
              <label className="block text-[11px] text-slate-400 mb-1">Paper or Book Title</label>
              <input
                type="text"
                value={citeTitle}
                onChange={(e) => setCiteTitle(e.target.value)}
                className="w-full bg-slate-900 border border-slate-800 rounded-lg px-3 py-1.5 text-xs text-slate-200"
              />
            </div>
            <div>
              <label className="block text-[11px] text-slate-400 mb-1">Journal / Publisher</label>
              <input
                type="text"
                value={citeSource}
                onChange={(e) => setCiteSource(e.target.value)}
                className="w-full bg-slate-900 border border-slate-800 rounded-lg px-3 py-1.5 text-xs text-slate-200"
              />
            </div>
          </div>

          {/* Footer Action Bar */}
          <div className="pt-2 flex items-center justify-between border-t border-slate-800">
            {/* Audio Voice Test */}
            <button
              type="button"
              onClick={handleTestAudio}
              className={`px-4 py-2 rounded-xl text-xs font-mono font-medium transition-colors flex items-center gap-2 ${
                isTestingAudio
                  ? 'bg-rose-900/60 border border-rose-500 text-rose-200'
                  : 'bg-slate-800 hover:bg-slate-700 text-slate-200'
              }`}
            >
              <span>{isTestingAudio ? '■ Stop Audio' : '▶ Test Voice Narration'}</span>
            </button>

            <div className="flex items-center gap-3">
              <button
                type="button"
                onClick={onClose}
                className="px-4 py-2 rounded-xl text-xs text-slate-400 hover:text-slate-200 transition-colors"
              >
                Cancel
              </button>
              <button
                type="submit"
                className="px-6 py-2.5 rounded-xl bg-cyan-600 hover:bg-cyan-500 text-white text-xs font-semibold shadow-lg shadow-cyan-600/20 transition-all hover:scale-[1.02] active:scale-[0.98]"
              >
                Publish 60s Lesson
              </button>
            </div>
          </div>
        </form>
      </div>
    </div>
  );
};
