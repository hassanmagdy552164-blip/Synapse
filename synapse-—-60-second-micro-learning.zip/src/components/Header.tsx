import React from 'react';
import { UserProgress } from '../types';

interface HeaderProps {
  currentView: 'stream' | 'catalog';
  onNavigate: (view: 'stream' | 'catalog') => void;
  onOpenVault: () => void;
  onOpenStudio: () => void;
  userProgress: UserProgress;
}

export const Header: React.FC<HeaderProps> = ({
  currentView,
  onNavigate,
  onOpenVault,
  onOpenStudio,
  userProgress,
}) => {
  return (
    <header className="sticky top-0 z-40 w-full bg-slate-950/90 backdrop-blur-md border-b border-slate-800">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 h-16 flex items-center justify-between">
        {/* Zone 1: Single text element wordmark */}
        <button
          type="button"
          onClick={() => onNavigate('stream')}
          className="text-xl font-serif font-bold tracking-tight text-slate-100 hover:text-cyan-300 transition-colors whitespace-nowrap shrink-0"
        >
          Synapse
        </button>

        {/* Zone 2: 4 clean text navigation links */}
        <nav className="hidden md:flex items-center gap-8 text-sm font-medium text-slate-400">
          <button
            type="button"
            onClick={() => onNavigate('stream')}
            className={`transition-colors whitespace-nowrap ${
              currentView === 'stream'
                ? 'text-cyan-300 font-semibold'
                : 'hover:text-slate-200'
            }`}
          >
            60s Stream
          </button>
          <button
            type="button"
            onClick={() => onNavigate('catalog')}
            className={`transition-colors whitespace-nowrap ${
              currentView === 'catalog'
                ? 'text-cyan-300 font-semibold'
                : 'hover:text-slate-200'
            }`}
          >
            Discover
          </button>
          <button
            type="button"
            onClick={onOpenVault}
            className="hover:text-slate-200 transition-colors whitespace-nowrap flex items-center gap-1.5"
          >
            <span>My Vault</span>
            <span className="text-[10px] font-mono text-cyan-400">
              ({userProgress.savedLessonIds.length})
            </span>
          </button>
          <button
            type="button"
            onClick={onOpenStudio}
            className="hover:text-slate-200 transition-colors whitespace-nowrap"
          >
            Author Studio
          </button>
        </nav>

        {/* Zone 3: 1-2 primary actions */}
        <div className="flex items-center gap-3">
          {/* CQ Quotient & Streak counter */}
          <button
            type="button"
            onClick={onOpenVault}
            className="hidden sm:flex items-center gap-2 px-3 py-1.5 rounded-lg bg-slate-900 border border-slate-800 text-xs font-mono text-slate-300 hover:border-slate-700 transition-colors whitespace-nowrap"
            title="Your Curiosity Quotient & Learning Streak"
          >
            <span className="text-amber-400">⚡</span>
            <span className="font-bold text-cyan-300 tabular-nums">
              {userProgress.cqPoints} CQ
            </span>
            <span className="text-slate-500">·</span>
            <span className="text-amber-300 tabular-nums">
              {userProgress.streakDays}d Streak
            </span>
          </button>

          {/* Primary Action Button */}
          <button
            type="button"
            onClick={onOpenStudio}
            className="px-4 py-2 text-xs font-semibold text-white bg-cyan-600 hover:bg-cyan-500 rounded-lg shadow-sm shadow-cyan-600/20 transition-all hover:scale-[1.02] active:scale-[0.98] whitespace-nowrap"
          >
            + Post 60s Lesson
          </button>
        </div>
      </div>
    </header>
  );
};
