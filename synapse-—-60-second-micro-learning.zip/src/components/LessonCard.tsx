import React, { useState } from 'react';
import { Lesson } from '../types';

interface LessonCardProps {
  lesson: Lesson;
  isSaved: boolean;
  isLiked: boolean;
  onPlay: (lesson: Lesson) => void;
  onToggleSave: (lessonId: string) => void;
  onToggleLike: (lessonId: string) => void;
  onSelectAuthor: (authorId: string) => void;
}

export const LessonCard: React.FC<LessonCardProps> = ({
  lesson,
  isSaved,
  isLiked,
  onPlay,
  onToggleSave,
  onToggleLike,
  onSelectAuthor,
}) => {
  const [imgError, setImgError] = useState(false);

  return (
    <div className="group relative bg-slate-900/60 hover:bg-slate-900 rounded-2xl border border-slate-800/80 hover:border-slate-700 transition-all duration-200 flex flex-col overflow-hidden shadow-sm">
      {/* Visual Media Container */}
      <div
        role="button"
        tabIndex={0}
        onClick={() => onPlay(lesson)}
        onKeyDown={(e) => { if (e.key === 'Enter' || e.key === ' ') { e.preventDefault(); onPlay(lesson); } }}
        className="cursor-pointer relative aspect-video w-full bg-slate-950 overflow-hidden"
      >
        {lesson.coverImage && !imgError ? (
          <img
            src={lesson.coverImage}
            alt={lesson.title}
            referrerPolicy="no-referrer"
            onError={() => setImgError(true)}
            className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300"
          />
        ) : (
          <div className="w-full h-full flex flex-col items-center justify-center p-4 bg-gradient-to-br from-slate-900 via-slate-950 to-indigo-950/40 text-center">
            <span className="text-[11px] font-mono text-cyan-400 uppercase tracking-wider">
              {lesson.discipline}
            </span>
            <span className="text-sm font-serif font-bold text-slate-200 mt-1 max-w-[200px]">
              {lesson.title}
            </span>
          </div>
        )}

        {/* 60s Duration & Gradient Scrim */}
        <div className="absolute inset-0 bg-gradient-to-t from-slate-950/90 via-transparent to-black/20" />
        
        {/* Play trigger overlay */}
        <div className="absolute inset-0 flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity">
          <div className="w-12 h-12 rounded-full bg-cyan-500/90 text-slate-950 flex items-center justify-center shadow-xl backdrop-blur-md transform scale-90 group-hover:scale-100 transition-transform">
            <span className="text-base font-bold ml-0.5">▶</span>
          </div>
        </div>

        {/* Unboxed timestamp & duration */}
        <div className="absolute bottom-2.5 left-3 right-3 flex items-center justify-between text-[11px] font-mono text-slate-300">
          <span className="flex items-center gap-1.5 bg-black/60 backdrop-blur-sm px-2 py-0.5 rounded text-cyan-300 font-semibold">
            01:00 Micro-Lesson
          </span>
          <span className="bg-black/60 backdrop-blur-sm px-2 py-0.5 rounded text-slate-300">
            {lesson.difficulty}
          </span>
        </div>
      </div>

      {/* Card Body */}
      <div className="p-4 flex-1 flex flex-col justify-between">
        <div>
          {/* Strict Zero-Pill unboxed metadata */}
          <div className="flex items-center gap-1.5 text-xs text-slate-400 mb-1.5">
            <span className="text-cyan-400/90 font-medium">{lesson.discipline}</span>
            <span aria-hidden="true">·</span>
            <span>{lesson.publishedAt}</span>
          </div>

          {/* Title */}
          <h3
            role="button"
            tabIndex={0}
            onClick={() => onPlay(lesson)}
            onKeyDown={(e) => { if (e.key === 'Enter' || e.key === ' ') { e.preventDefault(); onPlay(lesson); } }}
            className="cursor-pointer text-sm font-serif font-bold text-slate-100 group-hover:text-cyan-300 transition-colors line-clamp-2 leading-snug"
          >
            {lesson.title}
          </h3>

          {/* Tagline / Subtitle */}
          <p className="text-xs text-slate-400 line-clamp-2 mt-1 leading-relaxed">
            {lesson.tagline}
          </p>
        </div>

        {/* Footer: Author & Social Interactions */}
        <div className="mt-4 pt-3 border-t border-slate-800/80 flex items-center justify-between">
          {/* Author info */}
          <button
            type="button"
            onClick={() => onSelectAuthor(lesson.author.id)}
            className="flex items-center gap-2 text-left group/auth hover:opacity-80 transition-opacity"
          >
            <div className="w-6 h-6 rounded-full bg-slate-800 text-cyan-300 text-xs font-serif font-bold flex items-center justify-center border border-slate-700">
              {lesson.author.name.charAt(0)}
            </div>
            <div className="text-xs">
              <span className="font-medium text-slate-200 group-hover/auth:text-cyan-300 transition-colors">
                {lesson.author.name}
              </span>
            </div>
          </button>

          {/* Actions */}
          <div className="flex items-center gap-3 text-xs font-mono text-slate-400">
            {/* Mind Spark upvote */}
            <button
              type="button"
              onClick={() => onToggleLike(lesson.id)}
              className={`flex items-center gap-1 transition-colors ${
                isLiked ? 'text-amber-400' : 'hover:text-amber-300'
              }`}
              title="Thoughtful Mind Spark"
            >
              <span>⚡</span>
              <span className="tabular-nums">{lesson.mindSparks + (isLiked ? 1 : 0)}</span>
            </button>

            {/* Save to Vault */}
            <button
              type="button"
              onClick={() => onToggleSave(lesson.id)}
              className={`transition-colors ${
                isSaved ? 'text-cyan-400' : 'hover:text-cyan-300'
              }`}
              title="Save to Knowledge Vault"
            >
              {isSaved ? '★' : '☆'}
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
