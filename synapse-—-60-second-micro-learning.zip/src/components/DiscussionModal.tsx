import React, { useState } from 'react';
import { TeachBackComment } from '../types';

interface DiscussionModalProps {
  lessonTitle: string;
  comments: TeachBackComment[];
  isOpen: boolean;
  onClose: () => void;
  onAddComment: (comment: TeachBackComment) => void;
}

export const DiscussionModal: React.FC<DiscussionModalProps> = ({
  lessonTitle,
  comments,
  isOpen,
  onClose,
  onAddComment,
}) => {
  const [newText, setNewText] = useState('');
  const [isFeynman, setIsFeynman] = useState(true);

  if (!isOpen) return null;

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newText.trim()) return;

    const comment: TeachBackComment = {
      id: 'comment-' + Date.now(),
      authorName: 'You (Thinker)',
      authorHandle: '@curious_learner',
      timestamp: 'Just now',
      content: newText.trim(),
      likes: 1,
      isFeynmanSummary: isFeynman,
    };

    onAddComment(comment);
    setNewText('');
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm animate-fade-in">
      <div className="w-full max-w-xl bg-slate-900 border border-slate-800 rounded-3xl overflow-hidden shadow-2xl flex flex-col max-h-[85vh]">
        {/* Header */}
        <div className="p-5 border-b border-slate-800 flex items-center justify-between">
          <div>
            <div className="text-xs uppercase tracking-wider text-cyan-400 font-mono font-medium">
              Feynman Teach-Back Forum
            </div>
            <h3 className="text-base font-serif font-bold text-slate-100 truncate max-w-md mt-0.5">
              {lessonTitle}
            </h3>
          </div>
          <button
            type="button"
            onClick={onClose}
            className="w-8 h-8 rounded-full bg-slate-800 text-slate-400 hover:text-white flex items-center justify-center transition-colors text-sm"
          >
            ✕
          </button>
        </div>

        {/* Educational Principle Prompt */}
        <div className="px-5 py-3 bg-cyan-950/30 border-b border-cyan-900/30 flex items-start gap-2.5 text-xs text-cyan-200">
          <span className="font-mono text-cyan-400 font-bold shrink-0">💡 Feynman Rule:</span>
          <p className="leading-relaxed">
            The best way to solidify your neural pathways is to explain this in 1 or 2 plain-English sentences without jargon.
          </p>
        </div>

        {/* Comment list */}
        <div className="flex-1 overflow-y-auto p-5 flex flex-col gap-4">
          {comments.map((comment) => (
            <div
              key={comment.id}
              className={`p-4 rounded-2xl border flex flex-col gap-2 ${
                comment.isFeynmanSummary
                  ? 'bg-slate-950/80 border-cyan-900/40 ring-1 ring-cyan-500/20'
                  : 'bg-slate-950/40 border-slate-800'
              }`}
            >
              <div className="flex items-center justify-between text-xs">
                <div className="flex items-center gap-2">
                  <span className="font-semibold text-slate-200">{comment.authorName}</span>
                  <span className="text-slate-500 font-mono text-[11px]">{comment.authorHandle}</span>
                </div>
                <div className="flex items-center gap-2 text-[11px] text-slate-500 font-mono">
                  {comment.isFeynmanSummary && (
                    <span className="text-cyan-400 font-medium">Feynman Synthesis</span>
                  )}
                  <span>·</span>
                  <span>{comment.timestamp}</span>
                </div>
              </div>

              <p className="text-xs text-slate-300 leading-relaxed font-sans">
                {comment.content}
              </p>

              <div className="flex items-center justify-between text-[11px] text-slate-400 pt-1 font-mono">
                <button
                  type="button"
                  onClick={() => {}}
                  className="flex items-center gap-1 hover:text-cyan-300 transition-colors"
                >
                  <span>▲ Insightful</span>
                  <span>({comment.likes})</span>
                </button>
                <span className="text-slate-600">Verified Peer Note</span>
              </div>
            </div>
          ))}
        </div>

        {/* Input box */}
        <form onSubmit={handleSubmit} className="p-4 border-t border-slate-800 bg-slate-950/60 flex flex-col gap-2.5">
          <div className="flex items-center justify-between text-xs">
            <span className="text-slate-400 font-medium">Your 60s Teach-Back</span>
            <label className="flex items-center gap-2 text-[11px] text-slate-400 cursor-pointer">
              <input
                type="checkbox"
                checked={isFeynman}
                onChange={(e) => setIsFeynman(e.target.checked)}
                className="rounded border-slate-700 bg-slate-800 text-cyan-500 focus:ring-0"
              />
              <span>Tag as Feynman Synthesis</span>
            </label>
          </div>

          <div className="flex gap-2">
            <textarea
              rows={2}
              value={newText}
              onChange={(e) => setNewText(e.target.value)}
              placeholder="Explain this concept in plain English or add an insightful edge case..."
              className="flex-1 bg-slate-900 border border-slate-800 rounded-xl p-2.5 text-xs text-slate-100 placeholder-slate-500 focus:outline-none focus:border-cyan-500 resize-none font-sans"
            />
            <button
              type="submit"
              disabled={!newText.trim()}
              className="px-4 bg-cyan-600 hover:bg-cyan-500 disabled:opacity-40 disabled:hover:bg-cyan-600 text-white text-xs font-semibold rounded-xl transition-colors shrink-0 self-end h-10"
            >
              Post Note
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
