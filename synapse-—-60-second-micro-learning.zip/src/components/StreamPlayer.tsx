import React, { useState, useEffect, useRef, useCallback } from 'react';
import { Lesson, UserProgress } from '../types';
import { speechService } from '../services/speech';
import { ConceptVisualizer } from './ConceptVisualizer';
import { RetentionTabs } from './RetentionTabs';

interface StreamPlayerProps {
  lessons: Lesson[];
  currentLessonIndex: number;
  userProgress: UserProgress;
  onLessonChange: (index: number) => void;
  onToggleLike: (lessonId: string) => void;
  onToggleSave: (lessonId: string) => void;
  onToggleFollow: (authorId: string) => void;
  onPassQuiz: (lessonId: string) => void;
  onOpenDiscussion: (lesson: Lesson) => void;
  onSelectAuthor: (authorId: string) => void;
  onSwitchToCatalog: () => void;
}

export const StreamPlayer: React.FC<StreamPlayerProps> = ({
  lessons,
  currentLessonIndex,
  userProgress,
  onLessonChange,
  onToggleLike,
  onToggleSave,
  onToggleFollow,
  onPassQuiz,
  onOpenDiscussion,
  onSelectAuthor,
  onSwitchToCatalog,
}) => {
  const lesson = lessons[currentLessonIndex] || lessons[0];

  // Playback state
  const [isPlaying, setIsPlaying] = useState(true);
  const [currentTimeSec, setCurrentTimeSec] = useState(0);
  const [playbackRate, setPlaybackRate] = useState(1.0);
  const [isVoiceActive, setIsVoiceActive] = useState(true);
  const [copiedToast, setCopiedToast] = useState(false);

  const timerRef = useRef<number | null>(null);

  // Identify current beat from currentTimeSec
  const currentBeatIndex = lesson.beats.findIndex(
    (b) => currentTimeSec >= b.startSec && currentTimeSec < b.endSec
  );
  const safeBeatIndex = currentBeatIndex !== -1 ? currentBeatIndex : lesson.beats.length - 1;
  const currentBeat = lesson.beats[safeBeatIndex] || lesson.beats[0];

  // Speech narration integration
  const speakCurrentBeat = useCallback((beatIndex: number) => {
    if (!isVoiceActive) return;
    const beat = lesson.beats[beatIndex];
    if (beat && beat.script) {
      speechService.speak(beat.script);
    }
  }, [isVoiceActive, lesson]);

  // Handle lesson change cleanup
  useEffect(() => {
    setCurrentTimeSec(0);
    setIsPlaying(true);
    if (isVoiceActive) {
      speakCurrentBeat(0);
    }
    return () => {
      speechService.stop();
    };
  }, [currentLessonIndex, isVoiceActive, speakCurrentBeat]);

  // 60-Second Clock loop
  useEffect(() => {
    if (isPlaying) {
      const intervalMs = 100 / playbackRate;
      timerRef.current = window.setInterval(() => {
        setCurrentTimeSec((prev) => {
          const next = prev + 0.1;
          if (next >= 60) {
            // Reached 60s
            setIsPlaying(false);
            return 60;
          }

          // Check if crossed into a new beat for voice update
          const prevBeat = lesson.beats.findIndex((b) => prev >= b.startSec && prev < b.endSec);
          const nextBeat = lesson.beats.findIndex((b) => next >= b.startSec && next < b.endSec);
          if (prevBeat !== nextBeat && nextBeat !== -1 && isVoiceActive) {
            speakCurrentBeat(nextBeat);
          }

          return next;
        });
      }, intervalMs);
    } else {
      if (timerRef.current) clearInterval(timerRef.current);
      speechService.pause();
    }

    return () => {
      if (timerRef.current) clearInterval(timerRef.current);
    };
  }, [isPlaying, playbackRate, lesson, isVoiceActive, speakCurrentBeat]);

  // Keyboard navigation (ArrowUp/ArrowDown to switch lessons, Space to play/pause, M to mute)
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      // Don't intercept if user is typing in input or textarea
      if (['INPUT', 'TEXTAREA'].includes((e.target as HTMLElement).tagName)) {
        return;
      }

      if (e.key === 'ArrowDown' || e.key === 'j') {
        e.preventDefault();
        if (currentLessonIndex < lessons.length - 1) {
          onLessonChange(currentLessonIndex + 1);
        }
      } else if (e.key === 'ArrowUp' || e.key === 'k') {
        e.preventDefault();
        if (currentLessonIndex > 0) {
          onLessonChange(currentLessonIndex - 1);
        }
      } else if (e.key === ' ') {
        e.preventDefault();
        setIsPlaying((p) => {
          if (!p) {
            speechService.resume();
          } else {
            speechService.pause();
          }
          return !p;
        });
      } else if (e.key === 'm') {
        e.preventDefault();
        setIsVoiceActive((v) => {
          if (v) speechService.stop();
          return !v;
        });
      }
    };

    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [currentLessonIndex, lessons.length, onLessonChange]);

  const handleTogglePlay = () => {
    if (currentTimeSec >= 60) {
      setCurrentTimeSec(0);
      setIsPlaying(true);
      if (isVoiceActive) speakCurrentBeat(0);
      return;
    }

    if (isPlaying) {
      setIsPlaying(false);
      speechService.pause();
    } else {
      setIsPlaying(true);
      speechService.resume();
    }
  };

  const handleJumpToBeat = (index: number) => {
    const targetBeat = lesson.beats[index];
    if (targetBeat) {
      setCurrentTimeSec(targetBeat.startSec);
      if (isVoiceActive) {
        speakCurrentBeat(index);
      }
    }
  };

  const handleToggleVoice = () => {
    if (isVoiceActive) {
      speechService.stop();
      setIsVoiceActive(false);
    } else {
      setIsVoiceActive(true);
      speechService.speak(currentBeat.script);
    }
  };

  const handleShareCitation = () => {
    const citeText = `"${lesson.title}" by ${lesson.author.name} (${lesson.citation.source}, ${lesson.citation.year}) — Studied via Synapse 60s Micro-Learning.`;
    navigator.clipboard?.writeText(citeText);
    setCopiedToast(true);
    setTimeout(() => setCopiedToast(false), 2400);
  };

  const isLiked = userProgress.likedLessonIds.includes(lesson.id);
  const isSaved = userProgress.savedLessonIds.includes(lesson.id);
  const isFollowing = userProgress.followingAuthorIds.includes(lesson.author.id);
  const isQuizPassed = userProgress.passedQuizLessonIds.includes(lesson.id);

  // Formatted seconds
  const currentIntSec = Math.floor(currentTimeSec);
  const progressPercent = (currentTimeSec / 60) * 100;

  return (
    <div className="w-full max-w-6xl mx-auto px-4 sm:px-6 py-4 flex flex-col gap-4">
      {/* Top Stream Control Bar */}
      <div className="flex items-center justify-between border-b border-slate-800 pb-3">
        <div className="flex items-center gap-3">
          <button
            type="button"
            onClick={onSwitchToCatalog}
            className="flex items-center gap-1.5 text-xs text-slate-400 hover:text-slate-200 transition-colors"
          >
            <span>←</span>
            <span>All Catalog</span>
          </button>
          <span className="text-slate-700">|</span>
          <div className="flex items-center gap-2 text-xs font-mono">
            <span className="text-cyan-400 font-bold">
              Lesson {currentLessonIndex + 1} of {lessons.length}
            </span>
            <span className="text-slate-500 hidden sm:inline">
              (Use ↑ / ↓ keys or click next)
            </span>
          </div>
        </div>

        {/* Up / Down navigation buttons */}
        <div className="flex items-center gap-2">
          <button
            type="button"
            disabled={currentLessonIndex === 0}
            onClick={() => onLessonChange(currentLessonIndex - 1)}
            className="px-3 py-1.5 bg-slate-900 hover:bg-slate-800 disabled:opacity-30 disabled:hover:bg-slate-900 border border-slate-800 rounded-lg text-xs font-mono text-slate-300 transition-colors"
            title="Previous Lesson (↑)"
          >
            ▲ Prev 60s
          </button>
          <button
            type="button"
            disabled={currentLessonIndex === lessons.length - 1}
            onClick={() => onLessonChange(currentLessonIndex + 1)}
            className="px-3 py-1.5 bg-cyan-950 hover:bg-cyan-900 border border-cyan-800 disabled:opacity-30 text-cyan-300 text-xs font-mono rounded-lg transition-colors font-semibold"
            title="Next Lesson (↓)"
          >
            Next 60s ▼
          </button>
        </div>
      </div>

      {/* Main 60s Theatre Player */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-start">
        {/* Left / Center Zone: Visual Interactive Stage + Retention Deck (cols 1-9) */}
        <div className="lg:col-span-9 flex flex-col gap-4">
          {/* Stage Container */}
          <div className="relative aspect-video w-full bg-slate-950 rounded-3xl overflow-hidden border border-slate-800 shadow-2xl flex flex-col">
            {/* Visual simulation / diagram */}
            <div className="flex-1 w-full h-full relative">
              <ConceptVisualizer
                beat={currentBeat}
                coverImage={lesson.coverImage}
                currentTimeSec={currentTimeSec}
              />
            </div>

            {/* Subtitle / Script overlay bar */}
            <div className="p-4 bg-slate-950/95 backdrop-blur-md border-t border-slate-800/80 flex flex-col gap-2">
              <div className="flex items-center justify-between text-[11px] font-mono">
                <span className="text-cyan-400 uppercase tracking-wider font-semibold">
                  Beat 0{safeBeatIndex + 1}: {currentBeat.title}
                </span>
                <span className="text-slate-400">
                  {currentBeat.startSec}s – {currentBeat.endSec}s
                </span>
              </div>
              <p className="text-xs sm:text-sm text-slate-200 font-sans leading-relaxed">
                "{currentBeat.script}"
              </p>
            </div>

            {/* 60s Timeline & Beat Segments */}
            <div className="px-4 py-3 bg-slate-950 border-t border-slate-900 flex flex-col gap-2">
              {/* Segmented beat progress bar */}
              <div className="relative w-full h-2 bg-slate-800/80 rounded-full overflow-hidden flex">
                <div
                  className="h-full bg-cyan-400 transition-all duration-100 ease-linear rounded-full"
                  style={{ width: `${progressPercent}%` }}
                />
              </div>

              {/* Beat buttons & Playback controls */}
              <div className="flex items-center justify-between pt-1">
                {/* 4 Beat selector shortcuts */}
                <div className="flex items-center gap-1.5 overflow-x-auto scrollbar-none">
                  {lesson.beats.map((b, idx) => (
                    <button
                      key={b.id}
                      type="button"
                      onClick={() => handleJumpToBeat(idx)}
                      className={`px-2.5 py-1 text-[11px] font-mono rounded-md transition-colors whitespace-nowrap ${
                        safeBeatIndex === idx
                          ? 'bg-cyan-950 border border-cyan-500 text-cyan-300 font-bold'
                          : 'bg-slate-900 border border-slate-800 text-slate-400 hover:text-slate-200'
                      }`}
                    >
                      B{idx + 1}: {b.startSec}s
                    </button>
                  ))}
                </div>

                {/* Primary Play/Pause & Speed */}
                <div className="flex items-center gap-2 text-xs font-mono">
                  {/* Voice Narration toggle */}
                  <button
                    type="button"
                    onClick={handleToggleVoice}
                    className={`px-2.5 py-1 rounded-md border text-[11px] font-mono transition-colors ${
                      isVoiceActive
                        ? 'bg-slate-800 border-cyan-800 text-cyan-300'
                        : 'bg-slate-900 border-slate-800 text-slate-500'
                    }`}
                    title="Toggle synthesized voice narration"
                  >
                    {isVoiceActive ? '🔊 Voice On' : '🔇 Muted'}
                  </button>

                  {/* Playback speed */}
                  <button
                    type="button"
                    onClick={() => {
                      const rates = [1.0, 1.25, 1.5];
                      const nextRate = rates[(rates.indexOf(playbackRate) + 1) % rates.length];
                      setPlaybackRate(nextRate);
                      speechService.setRate(nextRate);
                    }}
                    className="px-2 py-1 bg-slate-900 border border-slate-800 hover:border-slate-700 text-slate-300 rounded-md transition-colors text-[11px]"
                  >
                    {playbackRate}x
                  </button>

                  {/* Play/Pause */}
                  <button
                    type="button"
                    onClick={handleTogglePlay}
                    className="w-8 h-8 rounded-full bg-cyan-500 hover:bg-cyan-400 text-slate-950 flex items-center justify-center font-bold text-xs transition-colors shrink-0 shadow-md"
                  >
                    {isPlaying ? '❚❚' : '▶'}
                  </button>

                  {/* Exact Countdown Clock */}
                  <div className="w-14 text-right font-mono text-xs font-bold text-slate-200 tabular-nums">
                    00:{currentIntSec < 10 ? `0${currentIntSec}` : currentIntSec}
                  </div>
                </div>
              </div>
            </div>
          </div>

          {/* Interactive Retention Deck: Micro-Quiz, Flashcard, Citation */}
          <RetentionTabs
            quiz={lesson.quiz}
            keyTakeaway={lesson.keyTakeaway}
            citation={lesson.citation}
            lessonId={lesson.id}
            isPassed={isQuizPassed}
            onPassQuiz={onPassQuiz}
          />
        </div>

        {/* Right Rail: Scholar Lockup & Social Actions (cols 10-12) */}
        <div className="lg:col-span-3 flex flex-col gap-4">
          {/* Author Card */}
          <div className="p-4 bg-slate-900/90 rounded-2xl border border-slate-800 flex flex-col gap-3">
            <div className="flex items-start gap-3">
              <button
                type="button"
                onClick={() => onSelectAuthor(lesson.author.id)}
                className="w-12 h-12 rounded-xl bg-cyan-950 border border-cyan-800 text-cyan-300 font-serif font-bold text-lg flex items-center justify-center shrink-0 hover:border-cyan-500 transition-colors"
              >
                {lesson.author.name.charAt(0)}
              </button>

              <div className="min-w-0 flex-1">
                <button
                  type="button"
                  onClick={() => onSelectAuthor(lesson.author.id)}
                  className="font-serif font-bold text-sm text-slate-100 hover:text-cyan-300 transition-colors truncate block text-left w-full"
                >
                  {lesson.author.name}
                </button>
                <div className="text-[11px] text-slate-400 font-mono">{lesson.author.handle}</div>
                <div className="text-[11px] text-slate-400 line-clamp-1 mt-0.5">
                  {lesson.author.institution}
                </div>
              </div>
            </div>

            <button
              type="button"
              onClick={() => onToggleFollow(lesson.author.id)}
              className={`w-full py-1.5 rounded-xl text-xs font-semibold transition-all ${
                isFollowing
                  ? 'bg-slate-800 text-slate-300 hover:bg-slate-700'
                  : 'bg-cyan-600 hover:bg-cyan-500 text-white'
              }`}
            >
              {isFollowing ? 'Following Scholar' : '+ Follow Scholar'}
            </button>
          </div>

          {/* Micro-Lesson Social Action Deck */}
          <div className="p-4 bg-slate-900/90 rounded-2xl border border-slate-800 flex flex-col gap-2.5">
            <div className="text-xs uppercase tracking-wider text-slate-400 font-mono pb-1 border-b border-slate-800">
              Intellectual Reaction
            </div>

            {/* Mind Spark Button */}
            <button
              type="button"
              onClick={() => onToggleLike(lesson.id)}
              className={`w-full p-2.5 rounded-xl border flex items-center justify-between text-xs font-medium transition-all ${
                isLiked
                  ? 'bg-amber-950/40 border-amber-500/80 text-amber-200'
                  : 'bg-slate-950/60 border-slate-800 text-slate-300 hover:border-slate-700'
              }`}
            >
              <span className="flex items-center gap-2">
                <span>⚡</span>
                <span>Mind Spark (Insight)</span>
              </span>
              <span className="font-mono tabular-nums font-bold">
                {lesson.mindSparks + (isLiked ? 1 : 0)}
              </span>
            </button>

            {/* Save to Vault Bookmark */}
            <button
              type="button"
              onClick={() => onToggleSave(lesson.id)}
              className={`w-full p-2.5 rounded-xl border flex items-center justify-between text-xs font-medium transition-all ${
                isSaved
                  ? 'bg-cyan-950/40 border-cyan-500/80 text-cyan-200'
                  : 'bg-slate-950/60 border-slate-800 text-slate-300 hover:border-slate-700'
              }`}
            >
              <span className="flex items-center gap-2">
                <span>{isSaved ? '★' : '☆'}</span>
                <span>{isSaved ? 'Saved in Vault' : 'Save to Vault'}</span>
              </span>
              <span className="font-mono text-slate-400 text-[11px]">
                {lesson.savesCount + (isSaved ? 1 : 0)} saves
              </span>
            </button>

            {/* Feynman Teach-Back Forum */}
            <button
              type="button"
              onClick={() => onOpenDiscussion(lesson)}
              className="w-full p-2.5 rounded-xl bg-slate-950/60 border border-slate-800 hover:border-slate-700 text-slate-300 hover:text-white flex items-center justify-between text-xs font-medium transition-all"
            >
              <span className="flex items-center gap-2">
                <span>💬</span>
                <span>Feynman Teach-Backs</span>
              </span>
              <span className="font-mono text-cyan-400 text-[11px]">
                {lesson.comments.length} notes
              </span>
            </button>

            {/* Share & Citation Link */}
            <button
              type="button"
              onClick={handleShareCitation}
              className="w-full p-2.5 rounded-xl bg-slate-950/60 border border-slate-800 hover:border-slate-700 text-slate-300 hover:text-white flex items-center justify-between text-xs font-medium transition-all"
            >
              <span className="flex items-center gap-2">
                <span>🔗</span>
                <span>Copy Paper Citation</span>
              </span>
              <span className="text-slate-500 text-[10px]">APA / BibTeX</span>
            </button>

            {copiedToast && (
              <div className="p-2 bg-emerald-950 border border-emerald-600 rounded-lg text-emerald-300 text-[11px] font-mono text-center animate-fade-in">
                ✓ Full Academic Citation Copied!
              </div>
            )}
          </div>

          {/* Quick Curriculum Up Next */}
          <div className="p-4 bg-slate-900/90 rounded-2xl border border-slate-800 flex flex-col gap-2">
            <div className="text-xs uppercase tracking-wider text-slate-400 font-mono">
              Up Next in Stream
            </div>
            {lessons
              .filter((_, i) => i !== currentLessonIndex)
              .slice(0, 2)
              .map((l) => (
                <div
                  key={l.id}
                  role="button"
                  tabIndex={0}
                  onClick={() => onLessonChange(lessons.findIndex((x) => x.id === l.id))}
                  onKeyDown={(e) => { if (e.key === 'Enter' || e.key === ' ') { e.preventDefault(); onLessonChange(lessons.findIndex((x) => x.id === l.id)); } }}
                  className="cursor-pointer p-2.5 bg-slate-950/60 hover:bg-slate-950 border border-slate-800/80 rounded-xl transition-all flex items-center justify-between group"
                >
                  <div className="min-w-0 flex-1 pr-2">
                    <div className="text-[10px] font-mono text-cyan-400">
                      {l.discipline} · 60s
                    </div>
                    <div className="text-xs font-serif font-bold text-slate-200 truncate group-hover:text-cyan-300">
                      {l.title}
                    </div>
                  </div>
                  <span className="text-slate-500 group-hover:text-cyan-400 text-xs">
                    ▶
                  </span>
                </div>
              ))}
          </div>
        </div>
      </div>
    </div>
  );
};
