import React from 'react';
import { Author, Lesson } from '../types';

interface AuthorProfileModalProps {
  author: Author | null;
  lessons: Lesson[];
  isOpen: boolean;
  isFollowing: boolean;
  onToggleFollow: (authorId: string) => void;
  onSelectLesson: (lesson: Lesson) => void;
  onClose: () => void;
}

export const AuthorProfileModal: React.FC<AuthorProfileModalProps> = ({
  author,
  lessons,
  isOpen,
  isFollowing,
  onToggleFollow,
  onSelectLesson,
  onClose,
}) => {
  if (!isOpen || !author) return null;

  const authorLessons = lessons.filter((l) => l.author.id === author.id);

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm animate-fade-in">
      <div className="w-full max-w-xl bg-slate-900 border border-slate-800 rounded-3xl overflow-hidden shadow-2xl flex flex-col max-h-[85vh]">
        {/* Header banner */}
        <div className="p-6 bg-gradient-to-r from-slate-950 via-slate-900 to-indigo-950/40 border-b border-slate-800 relative">
          <button
            type="button"
            onClick={onClose}
            className="absolute top-4 right-4 w-8 h-8 rounded-full bg-slate-800/80 text-slate-400 hover:text-white flex items-center justify-center text-sm"
          >
            ✕
          </button>

          <div className="flex items-start gap-4">
            <div className="w-16 h-16 rounded-2xl bg-cyan-950/80 border border-cyan-800/60 text-cyan-300 font-serif font-bold text-2xl flex items-center justify-center shadow-lg shrink-0">
              {author.name.charAt(0)}
            </div>

            <div className="flex-1 min-w-0">
              <div className="flex items-center gap-2">
                <h2 className="text-lg font-serif font-bold text-slate-100 truncate">
                  {author.name}
                </h2>
                {author.verified && (
                  <span className="text-cyan-400 text-sm" title="Verified Scholar / Practitioner">
                    ✓
                  </span>
                )}
              </div>
              <div className="text-xs text-slate-400 font-mono mt-0.5">{author.handle}</div>
              <div className="text-xs text-slate-300 mt-2 font-medium">
                {author.role} · <span className="text-slate-400">{author.institution}</span>
              </div>
            </div>
          </div>

          <div className="flex items-center justify-between mt-5 pt-4 border-t border-slate-800/80">
            <div className="flex items-center gap-4 text-xs font-mono">
              <div>
                <span className="font-bold text-slate-100">{author.followersCount.toLocaleString()}</span>{' '}
                <span className="text-slate-500">Learners</span>
              </div>
              <div>
                <span className="font-bold text-slate-100">{authorLessons.length}</span>{' '}
                <span className="text-slate-500">60s Lessons</span>
              </div>
            </div>

            <button
              type="button"
              onClick={() => onToggleFollow(author.id)}
              className={`px-4 py-1.5 rounded-xl text-xs font-semibold transition-all ${
                isFollowing
                  ? 'bg-slate-800 text-slate-300 hover:bg-slate-700'
                  : 'bg-cyan-600 hover:bg-cyan-500 text-white'
              }`}
            >
              {isFollowing ? 'Following' : 'Follow Scholar'}
            </button>
          </div>
        </div>

        {/* Authored Lessons */}
        <div className="p-6 flex-1 overflow-y-auto">
          <div className="text-xs uppercase tracking-wider text-slate-400 font-mono mb-3">
            Published 60-Second Micro-Lessons
          </div>

          <div className="flex flex-col gap-3">
            {authorLessons.map((l) => (
              <div
                key={l.id}
                role="button"
                tabIndex={0}
                onClick={() => {
                  onSelectLesson(l);
                  onClose();
                }}
                onKeyDown={(e) => { if (e.key === 'Enter' || e.key === ' ') { e.preventDefault(); onSelectLesson(l); onClose(); } }}
                className="cursor-pointer p-4 bg-slate-950/60 hover:bg-slate-950 border border-slate-800/80 hover:border-cyan-800/60 rounded-2xl transition-all flex items-center justify-between group"
              >
                <div className="min-w-0 flex-1 pr-3">
                  <div className="text-[11px] font-mono text-cyan-400 mb-0.5">
                    {l.discipline} · 60s
                  </div>
                  <h4 className="text-sm font-serif font-bold text-slate-100 group-hover:text-cyan-300 transition-colors">
                    {l.title}
                  </h4>
                  <p className="text-xs text-slate-400 truncate mt-1">
                    {l.tagline}
                  </p>
                </div>

                <div className="shrink-0 flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-slate-900 border border-slate-800 group-hover:border-cyan-600 text-xs font-mono text-cyan-400">
                  <span>Play</span>
                  <span>▶</span>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
};
