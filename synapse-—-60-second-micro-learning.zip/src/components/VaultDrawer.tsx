import React, { useState } from 'react';
import { Lesson, UserProgress } from '../types';

interface VaultDrawerProps {
  isOpen: boolean;
  onClose: () => void;
  userProgress: UserProgress;
  lessons: Lesson[];
  onSelectLesson: (lesson: Lesson) => void;
}

export const VaultDrawer: React.FC<VaultDrawerProps> = ({
  isOpen,
  onClose,
  userProgress,
  lessons,
  onSelectLesson,
}) => {
  const [activeTab, setActiveTab] = useState<'bookmarks' | 'flashcards' | 'metrics'>('bookmarks');
  const [activeCardIndex, setActiveCardIndex] = useState(0);
  const [isFlipped, setIsFlipped] = useState(false);

  if (!isOpen) return null;

  const savedLessons = lessons.filter((l) => userProgress.savedLessonIds.includes(l.id));
  const completedLessons = lessons.filter((l) => userProgress.completedLessonIds.includes(l.id));

  // Build flashcards deck from saved or completed lessons
  const flashcardDeck = (savedLessons.length > 0 ? savedLessons : lessons).map((l) => ({
    title: l.title,
    discipline: l.discipline,
    prompt: l.quiz.question,
    answer: l.keyTakeaway,
    author: l.author.name,
  }));

  const currentCard = flashcardDeck[activeCardIndex] || flashcardDeck[0];

  const handleNextCard = () => {
    setIsFlipped(false);
    setActiveCardIndex((prev) => (prev + 1) % flashcardDeck.length);
  };

  const handlePrevCard = () => {
    setIsFlipped(false);
    setActiveCardIndex((prev) => (prev - 1 + flashcardDeck.length) % flashcardDeck.length);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-end bg-black/70 backdrop-blur-sm animate-fade-in">
      <div className="w-full max-w-lg h-full bg-slate-900 border-l border-slate-800 shadow-2xl flex flex-col">
        {/* Header */}
        <div className="p-6 border-b border-slate-800 flex items-center justify-between">
          <div>
            <div className="text-xs uppercase tracking-wider text-amber-400 font-mono font-medium">
              Intellectual Archive
            </div>
            <h2 className="text-xl font-serif font-bold text-slate-100 mt-0.5">
              My Knowledge Vault
            </h2>
          </div>
          <button
            type="button"
            onClick={onClose}
            className="w-8 h-8 rounded-full bg-slate-800 text-slate-400 hover:text-white flex items-center justify-center text-sm"
          >
            ✕
          </button>
        </div>

        {/* Learning Daily Stats Bar */}
        <div className="p-5 bg-slate-950/60 border-b border-slate-800 grid grid-cols-3 gap-3 text-center">
          <div className="p-3 bg-slate-900 rounded-xl border border-slate-800">
            <div className="text-lg font-bold font-mono text-cyan-400">
              {userProgress.cqPoints}
            </div>
            <div className="text-[11px] text-slate-400 font-sans mt-0.5">Curiosity Score</div>
          </div>
          <div className="p-3 bg-slate-900 rounded-xl border border-slate-800">
            <div className="text-lg font-bold font-mono text-emerald-400">
              {userProgress.dailyLearningMinutes}m
            </div>
            <div className="text-[11px] text-slate-400 font-sans mt-0.5">Active Learned Today</div>
          </div>
          <div className="p-3 bg-slate-900 rounded-xl border border-slate-800">
            <div className="text-lg font-bold font-mono text-amber-400">
              {userProgress.streakDays} Days
            </div>
            <div className="text-[11px] text-slate-400 font-sans mt-0.5">Study Streak</div>
          </div>
        </div>

        {/* Tab switcher */}
        <div className="flex border-b border-slate-800 px-6 pt-2 gap-4">
          <button
            type="button"
            onClick={() => setActiveTab('bookmarks')}
            className={`pb-3 text-xs font-medium transition-colors border-b-2 ${
              activeTab === 'bookmarks'
                ? 'border-cyan-400 text-cyan-400'
                : 'border-transparent text-slate-400 hover:text-slate-200'
            }`}
          >
            Saved Micro-Lessons ({savedLessons.length})
          </button>
          <button
            type="button"
            onClick={() => setActiveTab('flashcards')}
            className={`pb-3 text-xs font-medium transition-colors border-b-2 ${
              activeTab === 'flashcards'
                ? 'border-amber-400 text-amber-400'
                : 'border-transparent text-slate-400 hover:text-slate-200'
            }`}
          >
            Spaced Repetition Deck
          </button>
          <button
            type="button"
            onClick={() => setActiveTab('metrics')}
            className={`pb-3 text-xs font-medium transition-colors border-b-2 ${
              activeTab === 'metrics'
                ? 'border-indigo-400 text-indigo-400'
                : 'border-transparent text-slate-400 hover:text-slate-200'
            }`}
          >
            Mastery Matrix
          </button>
        </div>

        {/* Content area */}
        <div className="flex-1 overflow-y-auto p-6">
          {activeTab === 'bookmarks' && (
            <div className="flex flex-col gap-3">
              {savedLessons.length === 0 ? (
                <div className="py-12 text-center text-slate-500 text-xs">
                  No saved lessons yet. Tap the bookmark icon while watching a 60s lesson to save it here.
                </div>
              ) : (
                savedLessons.map((l) => (
                  <div
                    key={l.id}
                    role="button"
                    tabIndex={0}
                    onClick={() => {
                      onSelectLesson(l);
                      onClose();
                    }}
                    onKeyDown={(e) => { if (e.key === 'Enter' || e.key === ' ') { e.preventDefault(); onSelectLesson(l); onClose(); } }}
                    className="cursor-pointer p-4 bg-slate-950/60 hover:bg-slate-950 border border-slate-800 rounded-2xl transition-all flex items-center justify-between group"
                  >
                    <div className="min-w-0 flex-1 pr-3">
                      <div className="text-[10px] font-mono text-cyan-400 mb-0.5">
                        {l.discipline} · 60s
                      </div>
                      <h4 className="text-xs font-serif font-bold text-slate-100 group-hover:text-cyan-300 transition-colors">
                        {l.title}
                      </h4>
                      <p className="text-[11px] text-slate-400 truncate mt-1">
                        By {l.author.name}
                      </p>
                    </div>

                    <div className="w-8 h-8 rounded-xl bg-slate-900 border border-slate-800 flex items-center justify-center text-cyan-400 group-hover:border-cyan-600 transition-colors shrink-0 text-xs">
                      ▶
                    </div>
                  </div>
                ))
              )}
            </div>
          )}

          {activeTab === 'flashcards' && currentCard && (
            <div className="flex flex-col gap-4">
              <div className="flex items-center justify-between text-xs font-mono text-slate-400">
                <span>Card {activeCardIndex + 1} of {flashcardDeck.length}</span>
                <span className="text-amber-400">{currentCard.discipline}</span>
              </div>

              <div
                role="button"
                tabIndex={0}
                onClick={() => setIsFlipped(!isFlipped)}
                onKeyDown={(e) => { if (e.key === 'Enter' || e.key === ' ') { e.preventDefault(); setIsFlipped(!isFlipped); } }}
                className="cursor-pointer min-h-[220px] p-6 bg-slate-950 rounded-2xl border border-slate-800 hover:border-amber-500/50 transition-all flex flex-col justify-between shadow-lg"
              >
                <div className="text-[10px] font-mono text-amber-400 uppercase tracking-wider">
                  {isFlipped ? 'REVERSE · TAKEAWAY TRUTH' : 'FRONT · RETENTION PROMPT'}
                </div>

                <div className="my-auto py-3">
                  {isFlipped ? (
                    <p className="text-xs text-slate-200 leading-relaxed font-sans">
                      {currentCard.answer}
                    </p>
                  ) : (
                    <p className="text-sm font-serif text-slate-100 leading-snug">
                      "{currentCard.prompt}"
                    </p>
                  )}
                </div>

                <div className="text-[11px] text-slate-500 font-mono flex items-center justify-between">
                  <span>Author: {currentCard.author}</span>
                  <span className="text-amber-400">Click to flip ↷</span>
                </div>
              </div>

              <div className="flex items-center justify-between pt-2">
                <button
                  type="button"
                  onClick={handlePrevCard}
                  className="px-4 py-2 bg-slate-800 hover:bg-slate-700 text-slate-300 text-xs font-medium rounded-xl transition-colors"
                >
                  ← Previous Card
                </button>
                <button
                  type="button"
                  onClick={handleNextCard}
                  className="px-4 py-2 bg-amber-600 hover:bg-amber-500 text-white text-xs font-semibold rounded-xl transition-colors"
                >
                  Next Recall Card →
                </button>
              </div>
            </div>
          )}

          {activeTab === 'metrics' && (
            <div className="flex flex-col gap-4">
              <div className="p-4 bg-slate-950 rounded-2xl border border-slate-800">
                <h4 className="text-xs font-serif font-bold text-slate-200 mb-2">
                  Cognitive Dividend vs Doomscrolling
                </h4>
                <p className="text-xs text-slate-400 leading-relaxed">
                  Instead of consuming 60-second dancing videos or sensational algorithms, you have converted{' '}
                  <strong className="text-cyan-300 font-mono">{userProgress.dailyLearningMinutes} minutes</strong> into permanent mental models today.
                </p>
              </div>

              <div className="flex flex-col gap-2">
                <div className="text-xs uppercase tracking-wider text-slate-400 font-mono">
                  Disciplines Explored
                </div>
                {[
                  { name: 'Neuroscience', percent: 80 },
                  { name: 'Quantum Physics', percent: 65 },
                  { name: 'Behavioral Economics', percent: 90 },
                  { name: 'Architectural History', percent: 75 },
                  { name: 'Algorithms & Systems', percent: 50 },
                ].map((d) => (
                  <div key={d.name} className="p-3 bg-slate-950/60 rounded-xl border border-slate-800">
                    <div className="flex items-center justify-between text-xs mb-1.5">
                      <span className="text-slate-300 font-medium">{d.name}</span>
                      <span className="font-mono text-cyan-400 text-[11px]">{d.percent}% Retention</span>
                    </div>
                    <div className="w-full h-1.5 bg-slate-800 rounded-full overflow-hidden">
                      <div
                        className="h-full bg-cyan-500 rounded-full"
                        style={{ width: `${d.percent}%` }}
                      />
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
