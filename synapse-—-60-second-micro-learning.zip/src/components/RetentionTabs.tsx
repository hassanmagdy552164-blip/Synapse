import React, { useState } from 'react';
import { motion } from 'motion/react';
import { QuizQuestion, Citation } from '../types';

interface RetentionTabsProps {
  quiz: QuizQuestion;
  keyTakeaway: string;
  citation: Citation;
  lessonId: string;
  isPassed: boolean;
  onPassQuiz: (lessonId: string) => void;
}

export const RetentionTabs: React.FC<RetentionTabsProps> = ({
  quiz,
  keyTakeaway,
  citation,
  lessonId,
  isPassed,
  onPassQuiz,
}) => {
  const [activeTab, setActiveTab] = useState<'quiz' | 'flashcard' | 'source'>('quiz');
  const [selectedOption, setSelectedOption] = useState<number | null>(null);
  const [isAnswered, setIsAnswered] = useState(isPassed);
  const [isFlipped, setIsFlipped] = useState(false);

  const handleSelectOption = (index: number) => {
    if (isAnswered) return;
    setSelectedOption(index);
    setIsAnswered(true);
    if (index === quiz.correctIndex) {
      onPassQuiz(lessonId);
    }
  };

  const handleResetQuiz = () => {
    setSelectedOption(null);
    setIsAnswered(false);
  };

  return (
    <div className="w-full bg-slate-900/90 rounded-2xl border border-slate-800 p-4 flex flex-col">
      {/* Tab Switcher */}
      <div className="flex items-center justify-between border-b border-slate-800 pb-3 mb-3">
        <div className="flex items-center gap-1">
          <button
            type="button"
            onClick={() => setActiveTab('quiz')}
            className={`px-3 py-1.5 text-xs font-medium rounded-lg transition-colors whitespace-nowrap ${
              activeTab === 'quiz'
                ? 'bg-slate-800 text-cyan-300 font-semibold shadow-sm'
                : 'text-slate-400 hover:text-slate-200'
            }`}
          >
            60s Concept Check
          </button>
          <button
            type="button"
            onClick={() => setActiveTab('flashcard')}
            className={`px-3 py-1.5 text-xs font-medium rounded-lg transition-colors whitespace-nowrap ${
              activeTab === 'flashcard'
                ? 'bg-slate-800 text-amber-300 font-semibold shadow-sm'
                : 'text-slate-400 hover:text-slate-200'
            }`}
          >
            Insight Flashcard
          </button>
          <button
            type="button"
            onClick={() => setActiveTab('source')}
            className={`px-3 py-1.5 text-xs font-medium rounded-lg transition-colors whitespace-nowrap ${
              activeTab === 'source'
                ? 'bg-slate-800 text-indigo-300 font-semibold shadow-sm'
                : 'text-slate-400 hover:text-slate-200'
            }`}
          >
            Academic Source
          </button>
        </div>

        {isPassed && activeTab === 'quiz' && (
          <span className="text-[11px] font-mono text-emerald-400 flex items-center gap-1">
            <span className="w-1.5 h-1.5 rounded-full bg-emerald-400" />
            +20 CQ Earned
          </span>
        )}
      </div>

      {/* Tab 1: Quiz */}
      {activeTab === 'quiz' && (
        <div className="flex flex-col gap-3">
          <div className="text-xs font-medium text-slate-200 font-serif leading-relaxed">
            {quiz.question}
          </div>

          <div className="flex flex-col gap-2">
            {quiz.options.map((option, idx) => {
              const isSelected = selectedOption === idx;
              const isCorrect = idx === quiz.correctIndex;
              let styleClasses = 'bg-slate-950/70 border-slate-800 text-slate-300 hover:border-slate-700';

              if (isAnswered) {
                if (isCorrect) {
                  styleClasses = 'bg-emerald-950/40 border-emerald-500/80 text-emerald-200 font-medium';
                } else if (isSelected) {
                  styleClasses = 'bg-rose-950/40 border-rose-500/80 text-rose-200';
                } else {
                  styleClasses = 'bg-slate-950/40 border-slate-800 text-slate-500 opacity-60';
                }
              }

              return (
                <button
                  key={idx}
                  type="button"
                  disabled={isAnswered}
                  onClick={() => handleSelectOption(idx)}
                  className={`w-full p-2.5 rounded-xl border text-xs text-left transition-all flex items-start gap-2.5 ${styleClasses}`}
                >
                  <span className="font-mono text-slate-400 uppercase text-[10px] shrink-0 mt-0.5">
                    {String.fromCharCode(65 + idx)}.
                  </span>
                  <span className="leading-snug">{option}</span>
                </button>
              );
            })}
          </div>

          {isAnswered && (
            <motion.div
              initial={{ opacity: 0, y: 4 }}
              animate={{ opacity: 1, y: 0 }}
              className="mt-2 p-3 bg-slate-950 rounded-xl border border-slate-800 text-xs text-slate-300 flex flex-col gap-1"
            >
              <div className="flex items-center justify-between font-mono text-[11px]">
                <span className={selectedOption === quiz.correctIndex ? 'text-emerald-400' : 'text-rose-400'}>
                  {selectedOption === quiz.correctIndex ? 'Correct Mental Model!' : 'Key Distinction to Note'}
                </span>
                <button
                  type="button"
                  onClick={handleResetQuiz}
                  className="text-slate-400 hover:text-slate-200 underline text-[10px]"
                >
                  Retry Check
                </button>
              </div>
              <p className="text-slate-400 leading-relaxed mt-1">{quiz.explanation}</p>
            </motion.div>
          )}
        </div>
      )}

      {/* Tab 2: Flashcard */}
      {activeTab === 'flashcard' && (
        <div
          role="button"
          tabIndex={0}
          onClick={() => setIsFlipped(!isFlipped)}
          onKeyDown={(e) => { if (e.key === 'Enter' || e.key === ' ') { e.preventDefault(); setIsFlipped(!isFlipped); } }}
          className="cursor-pointer min-h-[170px] p-4 bg-slate-950 rounded-xl border border-slate-800 flex flex-col justify-between hover:border-slate-700 transition-colors"
        >
          <div className="flex items-center justify-between text-[11px] font-mono text-amber-400/80">
            <span>{isFlipped ? 'REVERSE · CORE TAKEAWAY' : 'PROMPT · RETENTION CARD'}</span>
            <span className="text-slate-500">Click to flip ↷</span>
          </div>

          <div className="my-auto py-2">
            {isFlipped ? (
              <p className="text-xs text-slate-200 leading-relaxed font-sans">
                {keyTakeaway}
              </p>
            ) : (
              <p className="text-sm font-serif text-slate-100 italic">
                "{quiz.question}"
              </p>
            )}
          </div>

          <div className="text-[10px] text-slate-500 font-mono text-center">
            {isFlipped ? 'Mastered in 60 seconds' : 'Tap to test your recall'}
          </div>
        </div>
      )}

      {/* Tab 3: Sources & Academic Citations */}
      {activeTab === 'source' && (
        <div className="p-3 bg-slate-950 rounded-xl border border-slate-800 flex flex-col gap-2 text-xs">
          <div className="flex items-center justify-between text-slate-400 font-mono text-[11px]">
            <span>VERIFIED ACADEMIC LITERATURE</span>
            <span className="text-cyan-400">{citation.year}</span>
          </div>
          <div className="font-semibold text-slate-200 text-xs">
            {citation.title}
          </div>
          <div className="text-slate-400 text-[11px]">
            Published in <strong className="text-slate-300 font-medium">{citation.source}</strong>
          </div>
          {citation.doiOrUrl && (
            <div className="mt-1 pt-2 border-t border-slate-800/80 flex items-center justify-between text-[11px] font-mono text-slate-400">
              <span>DOI / Reference:</span>
              <span className="text-cyan-400 truncate max-w-[200px]">{citation.doiOrUrl}</span>
            </div>
          )}
        </div>
      )}
    </div>
  );
};
