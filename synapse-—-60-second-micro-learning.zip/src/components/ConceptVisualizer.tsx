import React, { useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { SlideBeat } from '../types';

interface ConceptVisualizerProps {
  beat: SlideBeat;
  coverImage?: string;
  currentTimeSec: number;
}

export const ConceptVisualizer: React.FC<ConceptVisualizerProps> = ({
  beat,
  coverImage,
  currentTimeSec,
}) => {
  const [activeTab, setActiveTab] = useState<'visual' | 'photo'>('visual');
  const [decoySelected, setDecoySelected] = useState<string | null>('bundle');
  const [bloomQuery, setBloomQuery] = useState('user:alice');
  const [theseusStep, setTheseusStep] = useState(3);

  // Render specific interactive diagrams based on diagramType
  const renderDiagram = () => {
    switch (beat.diagramType) {
      case 'synapse':
        return (
          <div className="relative w-full h-full flex flex-col items-center justify-center p-6 bg-slate-900/90 rounded-2xl overflow-hidden border border-slate-800">
            {/* Background pulsating glial wave */}
            <div className="absolute inset-0 bg-radial from-cyan-950/40 via-transparent to-transparent pointer-events-none" />
            
            <div className="text-center mb-4 z-10">
              <span className="text-xs uppercase tracking-wider text-cyan-400 font-semibold">
                Glymphatic Convective Flushing Model
              </span>
              <p className="text-xs text-slate-400 mt-1">
                Interstitial Space: <strong className="text-cyan-300">+60% Expansion</strong> during Slow-Wave Sleep
              </p>
            </div>

            {/* Simulated brain capillary and glial endfeet */}
            <div className="relative w-full max-w-md h-44 bg-slate-950/80 rounded-xl border border-cyan-900/50 p-4 flex flex-col justify-between overflow-hidden">
              {/* CSF Arterial Inflow */}
              <div className="flex items-center justify-between text-[11px] font-mono text-cyan-400 border-b border-cyan-900/40 pb-1">
                <span className="flex items-center gap-1.5">
                  <span className="w-2 h-2 rounded-full bg-cyan-400 animate-ping" />
                  CSF Inflow via Aqp4 Channels
                </span>
                <span className="text-slate-400">P = 12 mmHg</span>
              </div>

              {/* Particle flow visualization */}
              <div className="relative flex-1 flex items-center justify-around py-3">
                {[1, 2, 3, 4, 5, 6].map((i) => (
                  <motion.div
                    key={i}
                    animate={{
                      y: [-8, 8, -8],
                      opacity: [0.3, 0.9, 0.3],
                      scale: [0.9, 1.1, 0.9],
                    }}
                    transition={{
                      duration: 2.2,
                      repeat: Infinity,
                      delay: i * 0.25,
                      ease: 'easeInOut',
                    }}
                    className="flex flex-col items-center gap-1"
                  >
                    <div className="w-3 h-3 rounded-full bg-cyan-400 shadow-md shadow-cyan-500/40 border border-cyan-200" />
                    <span className="text-[9px] text-cyan-300 font-mono">CSF</span>
                  </motion.div>
                ))}

                {/* Glial endfoot barrier */}
                <div className="absolute inset-x-4 top-1/2 -translate-y-1/2 h-0.5 bg-gradient-to-r from-transparent via-cyan-500/50 to-transparent dashed" />
              </div>

              {/* Venous Outflow & Waste Clearance */}
              <div className="flex items-center justify-between text-[11px] font-mono text-amber-400 border-t border-slate-800 pt-1">
                <span>Toxic Amyloid-β Solute Clearance</span>
                <span className="text-emerald-400 font-semibold">2.1x Awake Rate</span>
              </div>
            </div>

            {beat.keyFormulaOrConcept && (
              <div className="mt-4 px-3 py-1.5 bg-slate-800/80 rounded-lg border border-slate-700 text-xs font-mono text-cyan-300 z-10">
                {beat.keyFormulaOrConcept}
              </div>
            )}
          </div>
        );

      case 'quantum':
        return (
          <div className="relative w-full h-full flex flex-col items-center justify-center p-6 bg-slate-900/90 rounded-2xl overflow-hidden border border-slate-800">
            <div className="text-center mb-4 z-10">
              <span className="text-xs uppercase tracking-wider text-indigo-400 font-semibold">
                No-Communication Bell State Simulator
              </span>
              <p className="text-xs text-slate-400 mt-1">
                State: |ψ⟩ = (|00⟩ + |11⟩) / √2 · Local Entropy = Maximum
              </p>
            </div>

            {/* Alice and Bob terminals */}
            <div className="w-full max-w-md grid grid-cols-2 gap-4">
              {/* Alice */}
              <div className="p-3 bg-slate-950 rounded-xl border border-indigo-900/60 flex flex-col items-center text-center">
                <span className="text-xs font-semibold text-indigo-300">Station Alice (Observer A)</span>
                <motion.div
                  animate={{ rotate: [0, 180, 360] }}
                  transition={{ duration: 6, repeat: Infinity, ease: 'linear' }}
                  className="my-3 w-12 h-12 rounded-full border-2 border-indigo-500/40 border-t-indigo-400 flex items-center justify-center font-mono text-xs text-white"
                >
                  Spin ↑
                </motion.div>
                <span className="text-[10px] text-slate-400 font-mono">P(0) = 50% | P(1) = 50%</span>
                <span className="text-[10px] text-amber-400 mt-1">Intrinsic Randomness</span>
              </div>

              {/* Bob */}
              <div className="p-3 bg-slate-950 rounded-xl border border-indigo-900/60 flex flex-col items-center text-center">
                <span className="text-xs font-semibold text-indigo-300">Station Bob (Observer B)</span>
                <motion.div
                  animate={{ rotate: [360, 180, 0] }}
                  transition={{ duration: 6, repeat: Infinity, ease: 'linear' }}
                  className="my-3 w-12 h-12 rounded-full border-2 border-indigo-500/40 border-b-cyan-400 flex items-center justify-center font-mono text-xs text-white"
                >
                  Spin ↓
                </motion.div>
                <span className="text-[10px] text-slate-400 font-mono">ρ_Bob = I / 2 (Pure Noise)</span>
                <span className="text-[10px] text-cyan-400 mt-1">Invariant Local State</span>
              </div>
            </div>

            {/* Entanglement bridge warning */}
            <div className="mt-4 px-3 py-1.5 bg-indigo-950/60 rounded-lg border border-indigo-800/50 text-xs font-mono text-indigo-200 text-center">
              Classical Light Channel Required to Decrypt Correlation
            </div>
          </div>
        );

      case 'decoy_pricing':
        return (
          <div className="relative w-full h-full flex flex-col items-center justify-center p-6 bg-slate-900/90 rounded-2xl overflow-hidden border border-slate-800">
            <div className="text-center mb-3">
              <span className="text-xs uppercase tracking-wider text-amber-400 font-semibold">
                Asymmetric Dominance Menu Simulator
              </span>
              <p className="text-xs text-slate-400 mt-1">
                Notice how the Print-Only decoy changes relative value perception.
              </p>
            </div>

            <div className="w-full max-w-md flex flex-col gap-2">
              {/* Option A */}
              <button
                type="button"
                onClick={() => setDecoySelected('web')}
                className={`w-full p-3 rounded-xl border text-left flex items-center justify-between transition-all ${
                  decoySelected === 'web'
                    ? 'bg-amber-950/30 border-amber-500/50'
                    : 'bg-slate-950/60 border-slate-800 hover:border-slate-700'
                }`}
              >
                <div>
                  <div className="text-xs font-semibold text-slate-200">Option 1: Web Only</div>
                  <div className="text-[11px] text-slate-400">Standard digital access</div>
                </div>
                <div className="text-right">
                  <div className="text-sm font-bold font-mono text-slate-200">$59</div>
                  <div className="text-[10px] text-slate-500">Without decoy: 68% pick this</div>
                </div>
              </button>

              {/* Option B: Decoy */}
              <button
                type="button"
                onClick={() => setDecoySelected('print')}
                className={`w-full p-3 rounded-xl border text-left flex items-center justify-between relative transition-all ${
                  decoySelected === 'print'
                    ? 'bg-rose-950/30 border-rose-500/50'
                    : 'bg-slate-950/60 border-slate-800 hover:border-slate-700'
                }`}
              >
                <div>
                  <div className="text-xs font-semibold text-rose-300 flex items-center gap-1.5">
                    Option 2: Print Only
                    <span className="text-[9px] uppercase tracking-wider text-rose-400 font-mono">The Decoy</span>
                  </div>
                  <div className="text-[11px] text-slate-400">Physical magazine only</div>
                </div>
                <div className="text-right">
                  <div className="text-sm font-bold font-mono text-rose-300">$125</div>
                  <div className="text-[10px] text-rose-400 font-medium">0% actually want this</div>
                </div>
              </button>

              {/* Option C: Target */}
              <button
                type="button"
                onClick={() => setDecoySelected('bundle')}
                className={`w-full p-3 rounded-xl border text-left flex items-center justify-between relative transition-all ${
                  decoySelected === 'bundle'
                    ? 'bg-emerald-950/40 border-emerald-500/60 ring-1 ring-emerald-500/40'
                    : 'bg-slate-950/60 border-slate-800 hover:border-slate-700'
                }`}
              >
                <div>
                  <div className="text-xs font-semibold text-emerald-300 flex items-center gap-1.5">
                    Option 3: Print + Web Bundle
                    <span className="text-[9px] uppercase tracking-wider text-emerald-400 font-mono">Target Winner</span>
                  </div>
                  <div className="text-[11px] text-slate-300">Complete physical & digital archive</div>
                </div>
                <div className="text-right">
                  <div className="text-sm font-bold font-mono text-emerald-300">$125</div>
                  <div className="text-[10px] text-emerald-400 font-medium">84% choose this with decoy!</div>
                </div>
              </button>
            </div>

            <div className="mt-3 text-xs text-slate-400 text-center font-mono">
              Perceived Value Anchor: Print is $125, so Web feels "Free"!
            </div>
          </div>
        );

      case 'pantheon':
        return (
          <div className="relative w-full h-full flex flex-col items-center justify-center p-6 bg-slate-900/90 rounded-2xl overflow-hidden border border-slate-800">
            <div className="text-center mb-3">
              <span className="text-xs uppercase tracking-wider text-amber-300 font-semibold">
                Structural Compression Profile of the Pantheon
              </span>
              <p className="text-xs text-slate-400 mt-1">
                Aggregate density steps down from 2,200 kg/m³ to 1,350 kg/m³ at the Oculus.
              </p>
            </div>

            {/* Stepped Dome Cross Section */}
            <div className="w-full max-w-md h-40 relative flex flex-col justify-end items-center">
              {/* Oculus Light beam */}
              <div className="absolute top-0 w-8 h-full bg-gradient-to-b from-amber-200/40 via-amber-200/10 to-transparent pointer-events-none" />
              
              {/* Oculus rim */}
              <div className="w-12 h-3 border-2 border-amber-300 rounded-full mb-1 flex items-center justify-center text-[9px] font-mono text-amber-200">
                Oculus (9m)
              </div>

              {/* Layer 3: Pumice concrete */}
              <div className="w-32 h-6 bg-stone-700 border border-stone-600 rounded-t-lg flex items-center justify-center text-[10px] text-stone-200 font-mono">
                Pumice (1,350 kg/m³)
              </div>

              {/* Layer 2: Tuff stone concrete */}
              <div className="w-52 h-7 bg-stone-800 border border-stone-700 flex items-center justify-center text-[10px] text-stone-300 font-mono">
                Tuff & Broken Brick (1,600 kg/m³)
              </div>

              {/* Layer 1: Travertine concrete base */}
              <div className="w-72 h-8 bg-stone-900 border border-stone-800 flex items-center justify-center text-[10px] text-amber-300 font-mono">
                Dense Travertine Base (2,200 kg/m³) · 6.4m Thick
              </div>
            </div>

            {/* MIT Lime Clast Callout */}
            <div className="mt-3 px-3 py-1.5 bg-stone-950 rounded-lg border border-stone-800 text-[11px] text-stone-300 text-center font-mono">
              Hot-Mixed Lime Clasts + Water ➔ Spontaneous Calcite (CaCO₃) Self-Healing
            </div>
          </div>
        );

      case 'bloom_filter':
        return (
          <div className="relative w-full h-full flex flex-col items-center justify-center p-6 bg-slate-900/90 rounded-2xl overflow-hidden border border-slate-800">
            <div className="text-center mb-3">
              <span className="text-xs uppercase tracking-wider text-emerald-400 font-semibold">
                Interactive Bloom Filter Bit Array
              </span>
              <p className="text-xs text-slate-400 mt-1">
                Zero false negatives guaranteed by k independent hash indices.
              </p>
            </div>

            {/* Bit Array Display */}
            <div className="w-full max-w-md bg-slate-950 p-4 rounded-xl border border-slate-800">
              <div className="flex items-center justify-between mb-2 text-xs">
                <span className="text-slate-400 font-mono">Query: "{bloomQuery}"</span>
                <span className="text-emerald-400 font-mono">Result: Definitely Absent (Skip Disk!)</span>
              </div>

              <div className="grid grid-cols-10 gap-1 my-3 font-mono text-xs text-center">
                {[1, 0, 1, 0, 0, 1, 0, 1, 1, 0].map((bit, idx) => (
                  <div
                    key={idx}
                    className={`py-2 rounded border ${
                      bit === 1
                        ? 'bg-emerald-950 border-emerald-600 text-emerald-300 font-bold'
                        : 'bg-slate-900 border-slate-800 text-slate-600'
                    }`}
                  >
                    {bit}
                  </div>
                ))}
              </div>

              <div className="flex items-center gap-2 mt-3">
                <input
                  type="text"
                  value={bloomQuery}
                  onChange={(e) => setBloomQuery(e.target.value)}
                  placeholder="Test key (e.g. user:bob)"
                  className="flex-1 bg-slate-900 border border-slate-700 rounded-lg px-2.5 py-1 text-xs text-slate-200 font-mono focus:outline-none focus:border-emerald-500"
                />
                <button
                  type="button"
                  onClick={() => setBloomQuery('malicious-url-' + Math.floor(Math.random() * 1000))}
                  className="px-2.5 py-1 bg-slate-800 hover:bg-slate-700 text-slate-300 text-xs rounded-lg transition-colors whitespace-nowrap"
                >
                  Generate Key
                </button>
              </div>
            </div>

            <div className="mt-3 text-xs text-emerald-300 font-mono text-center">
              If Bit == 0: Item 100% does NOT exist. Avoids expensive disk lookups.
            </div>
          </div>
        );

      case 'theseus':
        return (
          <div className="relative w-full h-full flex flex-col items-center justify-center p-6 bg-slate-900/90 rounded-2xl overflow-hidden border border-slate-800">
            <div className="text-center mb-3">
              <span className="text-xs uppercase tracking-wider text-amber-400 font-semibold">
                Plutarch's Plank Replacement Timeline
              </span>
              <p className="text-xs text-slate-400 mt-1">
                Step through the gradual renewal of structural timber.
              </p>
            </div>

            <div className="w-full max-w-md bg-slate-950 p-4 rounded-xl border border-slate-800">
              <div className="flex items-center justify-between text-xs font-mono text-slate-300 mb-3">
                <span>Decade: Year {theseusStep * 20}</span>
                <span className="text-amber-400">{theseusStep * 25}% Planks Replaced</span>
              </div>

              {/* Ship hull planks visual */}
              <div className="grid grid-cols-4 gap-2 my-2">
                {[0, 1, 2, 3].map((plankIdx) => {
                  const isReplaced = plankIdx < theseusStep;
                  return (
                    <div
                      key={plankIdx}
                      className={`p-2.5 rounded-lg border text-center text-[11px] font-mono transition-all ${
                        isReplaced
                          ? 'bg-amber-950/60 border-amber-600/80 text-amber-200'
                          : 'bg-stone-900 border-stone-800 text-stone-500'
                      }`}
                    >
                      Plank {plankIdx + 1}
                      <div className="text-[9px] mt-0.5">
                        {isReplaced ? 'New Timber' : 'Original Oak'}
                      </div>
                    </div>
                  );
                })}
              </div>

              <div className="flex items-center justify-between mt-4">
                <button
                  type="button"
                  onClick={() => setTheseusStep((prev) => Math.max(0, prev - 1))}
                  className="px-3 py-1 bg-slate-800 hover:bg-slate-700 text-slate-300 text-xs rounded-lg transition-colors"
                >
                  ← Earlier
                </button>
                <span className="text-xs text-slate-400 font-mono">
                  {theseusStep === 4 ? '100% Replaced (Continuous Pattern)' : 'Replacing Planks'}
                </span>
                <button
                  type="button"
                  onClick={() => setTheseusStep((prev) => Math.min(4, prev + 1))}
                  className="px-3 py-1 bg-slate-800 hover:bg-slate-700 text-slate-300 text-xs rounded-lg transition-colors"
                >
                  Later →
                </button>
              </div>
            </div>

            <div className="mt-3 text-xs text-amber-300 font-mono text-center">
              Identity exists in the persistent informational wave, not static wood.
            </div>
          </div>
        );

      default:
        // High polish general visualizer for any custom lesson
        return (
          <div className="relative w-full h-full flex flex-col items-center justify-center p-6 bg-slate-900/90 rounded-2xl overflow-hidden border border-slate-800">
            <div className="text-center mb-3">
              <span className="text-xs uppercase tracking-wider text-cyan-400 font-semibold">
                Conceptual Architecture Breakdown
              </span>
              <p className="text-xs text-slate-300 mt-1 font-serif text-lg">{beat.title}</p>
            </div>

            {beat.bulletPoints && beat.bulletPoints.length > 0 && (
              <div className="w-full max-w-md flex flex-col gap-2 my-2">
                {beat.bulletPoints.map((pt, i) => (
                  <div
                    key={i}
                    className="p-3 bg-slate-950/80 rounded-xl border border-slate-800 text-xs text-slate-200 flex items-start gap-2.5"
                  >
                    <span className="text-cyan-400 font-mono font-bold mt-0.5">0{i + 1}.</span>
                    <span>{pt}</span>
                  </div>
                ))}
              </div>
            )}

            {beat.keyFormulaOrConcept && (
              <div className="mt-3 px-3 py-2 bg-slate-800/80 rounded-lg border border-slate-700 text-xs font-mono text-cyan-300">
                {beat.keyFormulaOrConcept}
              </div>
            )}
          </div>
        );
    }
  };

  return (
    <div className="relative w-full h-full flex flex-col">
      {/* Switch between diagram & photo if photo exists */}
      {coverImage && (
        <div className="absolute top-3 right-3 z-20 flex items-center gap-1 bg-slate-950/80 backdrop-blur-md p-1 rounded-lg border border-slate-800 text-xs">
          <button
            type="button"
            onClick={() => setActiveTab('visual')}
            className={`px-2.5 py-1 rounded-md transition-colors ${
              activeTab === 'visual'
                ? 'bg-slate-800 text-white font-medium'
                : 'text-slate-400 hover:text-slate-200'
            }`}
          >
            Interactive Diagram
          </button>
          <button
            type="button"
            onClick={() => setActiveTab('photo')}
            className={`px-2.5 py-1 rounded-md transition-colors ${
              activeTab === 'photo'
                ? 'bg-slate-800 text-white font-medium'
                : 'text-slate-400 hover:text-slate-200'
            }`}
          >
            Editorial Visual
          </button>
        </div>
      )}

      {/* Main stage */}
      <div className="flex-1 w-full h-full relative">
        <AnimatePresence mode="wait">
          {activeTab === 'photo' && coverImage ? (
            <motion.div
              key="photo"
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              className="w-full h-full relative rounded-2xl overflow-hidden border border-slate-800"
            >
              <img
                src={coverImage}
                alt={beat.title}
                referrerPolicy="no-referrer"
                className="w-full h-full object-cover"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-slate-950 via-slate-950/30 to-transparent" />
              <div className="absolute bottom-4 left-4 right-4 p-4 bg-slate-950/90 backdrop-blur-md rounded-xl border border-slate-800">
                <span className="text-xs uppercase tracking-wider text-slate-400 font-mono">Key Takeaway</span>
                <p className="text-sm font-serif text-slate-100 mt-1">{beat.subtitle}</p>
              </div>
            </motion.div>
          ) : (
            <motion.div
              key="visual"
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              className="w-full h-full"
            >
              {renderDiagram()}
            </motion.div>
          )}
        </AnimatePresence>
      </div>
    </div>
  );
};
